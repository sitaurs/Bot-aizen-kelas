export const INTRO_MESSAGE = `👋 Halo, aku *Aizen* — asisten kelas JTD-2D.
Panggil aku: zen / aizen / zennn / zeen (dimanapun di kalimat).

✨ Yang bisa kulakuin:
• Jadwal & lokasi + dosen & WA (FO, Rektraf, Mikrokontroler, dll)
• Pengingat otomatis: 06.00 (semua matkul hari ini) + T-15 sebelum mulai
• Simpan & cari materi (foto/link/file) lalu kirim ulang
• Tugas/ujian/kas/barang bawaan (set/ubah/hapus)
• Bagi kelompok acak “adil”: “zen bentuk grup acak 5 kelompok”
• Mention semua: ketik @ll <pesan> (tanpa Gemini)
• Roles: ketua, bendahara, sekretaris, developer (+ fun role anak baik/nakal)

🔐 DM bot: khusus whitelist. Di grup, aku bakal nyapa pakai namamu.`;


