export const TAG_ALL_RATE_LIMIT_MS = 120000; // 2 minutes
export const TAG_ALL_BATCH_SIZE = 80;
export const TAG_ALL_ADMIN_ONLY = false;


