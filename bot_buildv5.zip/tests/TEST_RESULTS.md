# Automated Feature Tests

Total: 11/15 passed

- ✅ Access control - groups allow/deny
- ✅ Access control - DMs allow/deny & note takers
- ✅ Fuzzy trigger detection
- ✅ Mention all builds mentions list
- ❌ Tools: getSchedule & changeSchedule — getSchedule empty
- ✅ Tools: set/delete reminder
- ✅ Tools: set/delete exam
- ✅ Tools: carry items set/delete
- ✅ Role gating: cash reminders only for bendahara/developer/ketua
- ❌ @ll gating by fun role & core roles and cooldown/chunking — deny message missing
- ✅ !intro bypass
- ✅ Random groups: groupCount distribution and determinism
- ❌ Lecturer contact & class location — lecturer not found
- ❌ Fun role set/get & rate-limit quotes — setFunRole failed
- ✅ Materials: saveIncomingMedia + search + send
