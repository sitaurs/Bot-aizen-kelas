import 'dotenv/config';
import { GoogleGenAI, FunctionCallingConfigMode } from '@google/genai';
import { tools as toolDecls, handleToolCall } from '../src/ai/tools.js';
import { loadAllData } from '../src/storage/files.js';

type ConversationTurn = { input: string; expectCallNames?: string[]; expectContains?: string[] };

function sleep(ms: number) { return new Promise(res => setTimeout(res, ms)); }

function extractText(resp: any): string {
  try {
    const cand = resp?.candidates?.[0];
    const parts = cand?.content?.parts || [];
    const texts = parts.map((p: any) => p.text).filter(Boolean);
    return texts.join('\n');
  } catch { return ''; }
}

function extractFunctionCalls(resp: any): any[] {
  const calls: any[] = [];
  const cands = resp?.candidates || [];
  for (const cand of cands) {
    const parts = cand?.content?.parts || [];
    for (const part of parts) {
      if (part.functionCall) calls.push(part.functionCall);
    }
  }
  return calls;
}

async function runWithTools(client: GoogleGenAI, history: any[], userText: string) {
  const calledTools: string[] = [];
  const generateWithBackoff = async (payload: any) => {
    try {
      return await client.models.generateContent(payload);
    } catch (e: any) {
      if (e?.message?.includes('429')) {
        await sleep(24000);
        return await client.models.generateContent(payload);
      }
      throw e;
    }
  };
  let resp = await generateWithBackoff({
    model: 'gemini-2.5-flash',
    contents: [
      ...history,
      { role: 'user', parts: [{ text: userText }] }
    ],
    config: {
      tools: [{ functionDeclarations: toolDecls as any }],
      toolConfig: { functionCallingConfig: { mode: FunctionCallingConfigMode.AUTO } }
    }
  });

  // loop on function calls
  let safety = 0;
  while (safety++ < 5) {
    const calls = extractFunctionCalls(resp);
    if (!calls.length) break;
    const call = calls[0];
    if (call?.name) calledTools.push(call.name);
    let args: any = call.args;
    if (typeof args === 'string') {
      try { args = JSON.parse(args); } catch {}
    }
    const toolResult = await handleToolCall({ name: call.name, args });
    
    // Use fresh conversation for function response to avoid accumulation issues
    // retry/backoff for rate limits (simple)
    const doGenerate = async () => generateWithBackoff({
      model: 'gemini-2.5-flash',
      contents: [
        { role: 'user', parts: [{ text: userText }] },
        { role: 'model', parts: [{ functionCall: call }] },
        { role: 'user', parts: [{ functionResponse: { name: call.name, response: toolResult } }] }
      ]
    });
    resp = await doGenerate();
  }
  const text = extractText(resp);
  
  // Add to history for next turn
  history.push({ role: 'user', parts: [{ text: userText }] });
  if (text) {
    history.push({ role: 'model', parts: [{ text }] });
  }
  
  return { resp, text, called: calledTools };
}

async function main() {
  if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY missing');
  await loadAllData();

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
  const history: any[] = [
    { role: 'user', parts: [{ text: `Kamu adalah asisten kelas bernama ${process.env.BOT_NAME || 'Aizen'} untuk D4 Jaringan Komunikasi Digital.
Gunakan function-calling, timezone Asia/Jakarta. Untuk pertanyaan tanggal/hari ini, panggil getTodayInfo.
Jika parameter kurang, minta klarifikasi singkat.` }] }
  ];

  const cases: ConversationTurn[] = [
    // Jadwal & lokasi (4 kasus)
    { input: 'zen jadwal hari ini apa?', expectCallNames: ['getSchedule','getTodayInfo'] },
    { input: 'zen jadwal besok apa?', expectCallNames: ['getSchedule'], expectContains: ['besok','jadwal','tanggal'] },
    { input: 'zen lokasi kelas EM hari ini dimana?', expectCallNames: ['getClassLocation','getTodayInfo'], expectContains: ['tanggal','dimana','lokasi'] },
    { input: 'zen pindahin EM ke Senin 17:00-19:00 di B201 karena bentrok', expectCallNames: ['changeSchedule'], expectContains: ['senin','17:00','19:00'] },
    { input: 'zen ubah jadwal EM besok jam 08:00-10:00', expectCallNames: ['changeSchedule'] },
    { input: 'zen jadwal untuk rabu depan', expectCallNames: ['getSchedule'] },
    { input: 'zen dimana kelas Tekdig minggu depan?', expectCallNames: ['getClassLocation'] },

    // Reminder (5 kasus)
    { input: 'zen set reminder tugas EM Jumat 30 Agustus jam 17:00', expectCallNames: ['setReminder'] },
    { input: 'zen set reminder kas 50000 tanggal 24 Agustus jam 17:00', expectCallNames: ['setCashReminder'] },
    { input: 'zen set UTS EM 10 September 2025 jam 09:00 sampai 11:00 ruang A101', expectCallNames: ['setExam'] },
    { input: 'zen hapus reminder kas terakhir', expectCallNames: ['deleteCashReminder','deleteReminder'], expectContains: ['hapus','kas'] },
    { input: 'zen hapus uts terakhir', expectCallNames: ['deleteExam'] },
    { input: 'zen hapus reminder rem_xxxx', expectCallNames: ['deleteReminder'] },
    { input: 'zen reminder tugas EM hari ini jam 5', expectCallNames: ['setReminder'] },

    // Materials (4 kasus)
    { input: 'zen ada pembahasan vektor ga?', expectCallNames: ['queryMaterials'] },
    { input: 'zen cari materi EM tanggal 2025-08-22', expectCallNames: ['queryMaterials'] },
    { input: 'zen simpan materi EM hari ini caption pengantar EM', expectCallNames: ['addMaterials'], expectContains: ['file','mime','simpan'] },
    { input: 'zen cari materi EM keyword pengantar', expectCallNames: ['queryMaterials'] },
    { input: 'zen cari materi EM rentang 2025-08-01 sampai 2025-08-31', expectCallNames: ['queryMaterials'] },

    // Kontak dosen (4 kasus)
    { input: 'zen kontak dosen kalkulus siapa?', expectCallNames: ['getLecturerContact'] },
    { input: 'zen nomor Dr Siti ada?', expectCallNames: ['getLecturerContact'] },
    { input: 'zen email dosen kalkulus', expectCallNames: ['getLecturerContact'] },
    { input: 'zen dosen EM siapa?', expectCallNames: ['getLecturerContact'] },
    { input: 'zen kontak dosen basis data', expectCallNames: ['getLecturerContact'] },

    // Barang bawaan (4 kasus)
    { input: 'zen set barang bawaan EM kalkulator dan penggaris', expectCallNames: ['setCarryItem'] },
    { input: 'zen hapus barang penggaris untuk EM', expectCallNames: ['deleteCarryItem'] },
    { input: 'zen hapus semua barang EM', expectCallNames: ['deleteCarryItem'] },
    { input: 'zen set barang bawaan Medan Elektromagnetik spidol papan hapus penggaris', expectCallNames: ['setCarryItem','deleteCarryItem'] },
    { input: 'zen set barang bawaan Kalkulus penghapus penggaris T', expectCallNames: ['setCarryItem'] },

    // Group & hydration (3 kasus)
    { input: '@ll besok kumpul jam 7 ya', expectCallNames: ['mentionAll'], expectContains: ['jid','grup','mention'] },
    { input: 'zen set hidrasi 2500 ml sehari gelas 250', expectCallNames: ['setHydrationPlan'] },
    { input: 'zen hidrasi target apa?', expectCallNames: ['getHydrationPlan'] }
  ];

  const results: { name: string; ok: boolean; info?: string }[] = [];

  for (const c of cases) {
    await sleep(8000); // extra delay to avoid rate limit on free tier
    console.log(`\n[CASE] ${c.input}`);
    const { resp, text, called } = await runWithTools(ai, history, c.input);
    const calls = called;
    console.log(`[CALLED] ${calls.join(', ') || '(none)'}`);
    console.log(`[REPLY] ${(text || '').slice(0, 300)}`);
    const okCall = c.expectCallNames ? c.expectCallNames.some(n => calls.includes(n)) : false;
    const okText = c.expectContains ? c.expectContains.some(s => (text || '').toLowerCase().includes(s)) : false;
    const okEither = (c.expectCallNames ? okCall : false) || (c.expectContains ? okText : false) || (!c.expectCallNames && !c.expectContains && !!text);
    const ok = okEither && Boolean(text && text.length > 0);
    results.push({ name: c.input, ok, info: ok ? undefined : `calls=${calls.join(',')} text=${text?.slice(0,200)}` });
  }

  const pass = results.filter(r => r.ok).length;
  const total = results.length;
  const lines = results.map(r => `- ${r.ok ? '✅' : '❌'} ${r.name}${r.ok ? '' : ` — ${r.info}`}`);
  const summary = [`# Gemini Conversation Tests`, '', `Total: ${pass}/${total} passed`, '', ...lines, ''].join('\n');
  await (await import('fs/promises')).writeFile('tests/AI_TEST_RESULTS.md', summary, 'utf8');
  console.log(summary);
  if (pass !== total) process.exit(1);
}

main().catch(e => { console.error(e); process.exit(1); });


