# 🧩 Arsitektur Teknis — Aizen

## 🏗️ Komponen
- **WhatsApp Layer (Baileys)**: koneksi, login QR/pairing, event, upsert messages.
- **AI Layer (Gemini)**: function-calling, klarifikasi, retry + rotasi API key, prompt sistem.
- **Features Layer**: materials, mentions, NLU placeholder.
- **Scheduler Layer**: cron jobs WIB (ringkasan, T-15, barang bawaan, hidrasi).
- **Storage Layer**: IO JSON + cache + path helpers (materials index).
- **Utils**: logger, time (WIB) + normalisasi, id, access whitelist.

## 🔄 Alur Pesan (High Level)
1. `handlers.ts` menerima pesan ↦ cek `fromMe`/whitelist ↦ ekstrak teks/media.
2. Jika `@ll` diawal → `mentions` ke semua partisipan grup.
3. Jika trigger nama bot terdeteksi → delegasi ke `ai/gemini.ts`:
   - bentuk sistem prompt + daftar tools
   - panggil model → jika `functionCall` → route ke `ai/tools.ts.handleToolCall`
   - kirim `functionResponse` → model merangkai balasan natural
4. Balasan dikirim ke WhatsApp.

## 🧠 Flow Function-Calling
- Model → `functionCall(name,args)`
- App → eksekusi handler → hasil → `functionResponse { name, response }`
- Model → menulis jawaban natural (mengacu hasil fungsi)

## 🧭 Clarify Loop
- **App-led**: handler cek slot wajib → jika ada yang kurang, tanya 1 hal terpenting (close-ended). Contoh: jam mulai & selesai.
- **Model-led**: panggil tool `askClarify(question, expect)` untuk meminta model menyusun pertanyaan natural saat intent tidak jelas.

## 🗓️ Normalisasi Tanggal
- `normalizeRelativeDate()` mengubah kata relatif ("hari ini", "besok", "Senin") menjadi tanggal absolut WIB.
- Dipakai oleh `getSchedule` dan `getClassLocation`.

## 🔁 Rotasi API Key
- Kunci di `.env`: `GEMINI_API_KEY` dan/atau `GEMINI_API_KEY_1..N`.
- Saat error 429 → rotate ke key berikut + retry.
- Indeks aktif disimpan di `data/aiState.json` (`keyIndex`) dan dipulihkan saat boot.

## 🧱 Modul File Kunci
- `src/ai/gemini.ts` — integrasi model, prompt, retry & rotasi API, jalur FC.
- `src/ai/tools.ts` — deklarasi tools, router, dan handler fitur.
- `src/wa/connect.ts` — koneksi & event Baileys.
- `src/wa/handlers.ts` — routing pesan, akses kontrol, delegasi fitur/AI.
- `src/scheduler/cron.ts` — cron jobs WIB.
- `src/storage/files.ts` — IO JSON + cache + ensure folder + materials index.

## 💽 Persistensi Data
- JSON di `data/`: jadwal, pengingat, ujian, kas, dosen, barang, materials index, hidrasi, `aiState`.
- Media di `storage/<Course>/<YYYY-MM-DD>/...`.

[🔙 Kembali ke README](../README.md)
