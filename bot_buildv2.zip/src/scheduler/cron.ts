import cron from 'node-cron';
import { WASocket } from '@whiskeysockets/baileys';
import { GeminiAI } from '../ai/gemini.js';
import { getData } from '../storage/files.js';
import { getToday, getDayName, now, addMinutes } from '../utils/time.js';
import dayjs from 'dayjs';
import { logger } from '../utils/logger.js';
import { sendTextMessage } from '../wa/handlers.js';

interface CronParams {
  sock: WASocket;
  ai: GeminiAI;
}

export async function initCron({ sock, ai }: CronParams): Promise<void> {
  const groupJid = process.env.GROUP_JID;
  
  if (!groupJid) {
    logger.warn('GROUP_JID not set, skipping cron initialization');
    return;
  }

  // 06:00 WIB - Ringkasan jadwal hari ini
  cron.schedule('0 6 * * *', async () => {
    await sendDailySchedule(sock, groupJid);
  }, { 
    timezone: 'Asia/Jakarta' 
  });

  // T-15 menit sebelum kelas - Pengingat kelas
  cron.schedule('*/1 * * * *', async () => {
    await checkUpcomingClasses(sock, groupJid);
  }, { 
    timezone: 'Asia/Jakarta' 
  });

  // 21:00 WIB - Pengingat barang bawaan besok
  cron.schedule('0 21 * * *', async () => {
    await sendCarryItemsReminder(sock, groupJid);
  }, { 
    timezone: 'Asia/Jakarta' 
  });

  // 06:00 WIB - Pengingat barang bawaan pagi
  cron.schedule('0 6 * * *', async () => {
    await sendCarryItemsReminder(sock, groupJid, true);
  }, { 
    timezone: 'Asia/Jakarta' 
  });

  // 19:00 WIB - Minta materi harian dari note takers
  cron.schedule('0 19 * * *', async () => {
    await requestDailyMaterials(sock);
  }, { 
    timezone: 'Asia/Jakarta' 
  });

  // Hydration reminders (setiap 2 jam dari 08:00-20:00)
  cron.schedule('0 8,10,12,14,16,18,20 * * *', async () => {
    await sendHydrationReminder(sock, groupJid);
  }, { 
    timezone: 'Asia/Jakarta' 
  });

  logger.info('Cron jobs initialized');
}

async function sendDailySchedule(sock: WASocket, groupJid: string): Promise<void> {
  try {
    const today = getToday();
    const dayName = getDayName(today);
    const schedule = getData('schedule');
    
    const daySchedule = (schedule.days as any)[dayName as string] || [];
    const overrides = schedule.overrides.filter((o: any) => o.date === today);
    
    if (daySchedule.length === 0 && overrides.length === 0) {
      await sendTextMessage(sock, groupJid, '📅 Hari ini tidak ada jadwal kelas! 😴');
      return;
    }
    
    let message = `📅 *JADWAL HARI INI* (${dayName})\n\n`;
    
    // Regular schedule
    if (daySchedule.length > 0) {
      message += '*Jadwal Regular:*\n';
      daySchedule.forEach((cls: any, index: number) => {
        message += `${index + 1}. ${cls.course}\n`;
        message += `   ⏰ ${cls.start} - ${cls.end}\n`;
        message += `   🏢 ${cls.room}\n\n`;
      });
    }
    
    // Overrides
    if (overrides.length > 0) {
      message += '*Jadwal Khusus:*\n';
      overrides.forEach((override: any, index: number) => {
        message += `${index + 1}. ${override.course}\n`;
        message += `   ⏰ ${override.start} - ${override.end}\n`;
        message += `   🏢 ${override.room || 'TBD'}\n`;
        message += `   📝 ${override.reason}\n\n`;
      });
    }
    
    await sendTextMessage(sock, groupJid, message);
  } catch (error) {
    logger.error({ err: error as any }, 'Error sending daily schedule');
  }
}

async function checkUpcomingClasses(sock: WASocket, groupJid: string): Promise<void> {
  try {
    const currentTime = now();
    const today = getToday();
    const dayName = getDayName(today);
    const schedule = getData('schedule');
    
    const daySchedule = (schedule.days as any)[dayName as string] || [];
    const overrides = schedule.overrides.filter((o: any) => o.date === today);
    
    const allClasses = [...daySchedule, ...overrides];
    
    for (const cls of allClasses) {
      const classTime = currentTime.format('YYYY-MM-DD') + 'T' + cls.start + ':00';
      const classStart = dayjs.tz(classTime, 'Asia/Jakarta');
      const fifteenMinutesBefore = classStart.subtract(15, 'minute');
      
      // Check if it's time to send reminder (within 1 minute window)
      if (currentTime.isBetween(fifteenMinutesBefore, fifteenMinutesBefore.add(1, 'minute'))) {
        const message = `⏰ *PENGINGAT KELAS*\n\n` +
                       `📚 ${cls.course}\n` +
                       `⏰ ${cls.start} - ${cls.end}\n` +
                       `🏢 ${cls.room}\n\n` +
                       `Kelas akan dimulai dalam 15 menit! 🚀`;
        
        await sendTextMessage(sock, groupJid, message);
      }
    }
  } catch (error) {
    logger.error({ err: error as any }, 'Error checking upcoming classes');
  }
}

async function sendCarryItemsReminder(sock: WASocket, groupJid: string, isMorning: boolean = false): Promise<void> {
  try {
    const tomorrow = now().add(1, 'day');
    const dayName = getDayName(tomorrow.format('YYYY-MM-DD'));
    const schedule = getData('schedule');
    const items = getData('items');
    
    const daySchedule = (schedule.days as any)[dayName as string] || [];
    const overrides = schedule.overrides.filter((o: any) => o.date === tomorrow.format('YYYY-MM-DD'));
    
    const allClasses = [...daySchedule, ...overrides];
    
    if (allClasses.length === 0) {
      return; // No classes tomorrow
    }
    
    const timePrefix = isMorning ? '🌅 PAGI' : '🌙 MALAM';
    let message = `📦 *PENGINGAT BARANG BAWAAN* (${timePrefix})\n\n`;
    message += `Untuk besok (${dayName}):\n\n`;
    
    const courseItems = new Map();
    
    for (const cls of allClasses) {
      const courseItems = items[cls.course] || [];
      if (courseItems.length > 0) {
        message += `📚 *${cls.course}*\n`;
        courseItems.forEach((item: string) => {
          message += `   • ${item}\n`;
        });
        message += '\n';
      }
    }
    
    if (message.includes('•')) {
      await sendTextMessage(sock, groupJid, message);
    }
  } catch (error) {
    logger.error({ err: error as any }, 'Error sending carry items reminder');
  }
}

async function requestDailyMaterials(sock: WASocket): Promise<void> {
  try {
    const noteTakers = process.env.NOTE_TAKERS?.split(',') || [];
    
    if (noteTakers.length === 0) {
      logger.warn('No note takers configured');
      return;
    }
    
    const message = `📝 *KOLEKSI MATERI HARIAN*\n\n` +
                   `Halo! Hari ini belajar apa aja? 📚\n\n` +
                   `Tolong kirim:\n` +
                   `• Foto papan tulis 📸\n` +
                   `• File PPT/PDF 📄\n` +
                   `• Link materi 🔗\n` +
                   `• Atau catatan lainnya 📝\n\n` +
                   `Kirim satu-satu ya, dengan caption singkat untuk setiap item! 😊`;
    
    for (const jid of noteTakers) {
      try {
        await sendTextMessage(sock, jid, message);
        logger.info(`Daily materials request sent to ${jid}`);
      } catch (error) {
        logger.error({ err: error as any, jid }, 'Error sending daily materials request');
      }
    }
  } catch (error) {
    logger.error({ err: error as any }, 'Error requesting daily materials');
  }
}

async function sendHydrationReminder(sock: WASocket, groupJid: string): Promise<void> {
  try {
    const dailyGoal = parseInt(process.env.HYDRATION_DAILY_GOAL_ML || '2000');
    const glassSize = parseInt(process.env.HYDRATION_GLASS_SIZE_ML || '250');
    const glassesNeeded = Math.ceil(dailyGoal / glassSize);
    
    const message = `💧 *PENGINGAT MINUM AIR*\n\n` +
                   `Target hari ini: ${dailyGoal}ml (${glassesNeeded} gelas)\n` +
                   `Ukuran gelas: ${glassSize}ml\n\n` +
                   `Jangan lupa minum air ya! 💪\n` +
                   `Tubuh sehat, pikiran jernih! 🧠✨`;
    
    await sendTextMessage(sock, groupJid, message);
  } catch (error) {
    logger.error({ err: error as any }, 'Error sending hydration reminder');
  }
}
