import { WASocket } from '@whiskeysockets/baileys';
import { GeminiAI } from '../ai/gemini.js';
import { getData, saveData } from '../storage/files.js';
import { cleanTriggerFromText } from './fuzzy-trigger.js';
import { logger } from '../utils/logger.js';
import { WhatsAppMessage, ChatContext } from '../types/index.js';

const ai = new GeminiAI();

interface AIClarifyOrActParams {
  sock: WASocket;
  msg: WhatsAppMessage;
  text: string;
}

export async function aiClarifyOrAct({ sock, msg, text }: AIClarifyOrActParams): Promise<string> {
  const jid = msg.key.remoteJid!;
  const cleanText = cleanTriggerFromText(text);
  
  try {
    // Get context for this chat
    const context = getData('context');
    const chatContext = context[jid];
    
    // If there's pending action, try to complete it
    if (chatContext?.pendingAction) {
      const result = await tryCompletePendingAction(cleanText, chatContext.pendingAction);
      
      if (result.completed) {
        // Clear pending action
        await updateContext(jid, null);
        return result.response;
      } else {
        // Still need more info
        return result.response;
      }
    }
    
    // Process new request
    const response = await ai.chatAndAct(cleanText, chatContext?.lastMessage);
    
    // Check if AI needs clarification
    if (needsClarification(response)) {
      // Save context for next interaction
      await updateContext(jid, {
        type: 'clarification',
        params: { originalText: cleanText }
      });
    }
    
    return response;
  } catch (error) {
    logger.error({ err: error as any }, 'Error in AI clarify or act');
    return 'Maaf, terjadi kesalahan dalam memproses permintaan Anda.';
  }
}

function needsClarification(response: string): boolean {
  const clarificationKeywords = [
    'jam berapa',
    'tanggal berapa',
    'mata kuliah apa',
    'ruangan mana',
    'kapan',
    'dimana',
    'siapa',
    'berapa',
    'tolong jelaskan',
    'bisa dijelaskan',
    'mohon konfirmasi'
  ];
  
  const lowerResponse = response.toLowerCase();
  return clarificationKeywords.some(keyword => lowerResponse.includes(keyword));
}

async function tryCompletePendingAction(text: string, pendingAction: any): Promise<{ completed: boolean; response: string }> {
  try {
    // Try to extract information from the response
    const extractedInfo = extractInfoFromText(text, pendingAction.type);
    
    if (extractedInfo.complete) {
      // Complete the action with extracted info
      const completeParams = { ...pendingAction.params, ...extractedInfo.data };
      const response = await ai.chatAndAct(`Complete action: ${JSON.stringify(completeParams)}`);
      return { completed: true, response };
    } else {
      // Still need more info
      return { completed: false, response: extractedInfo.prompt || 'Bisa sebutkan detailnya lagi, ya?' };
    }
  } catch (error) {
    logger.error({ err: error as any }, 'Error completing pending action');
    return { completed: false, response: 'Maaf, terjadi kesalahan. Bisa diulang lagi?' };
  }
}

function extractInfoFromText(text: string, actionType: string): { complete: boolean; data: any; prompt?: string } {
  const lowerText = text.toLowerCase();
  
  switch (actionType) {
    case 'changeSchedule':
      // Extract time and date information
      const timeMatch = text.match(/(\d{1,2}):(\d{2})\s*(sore|pagi|siang|malam)?/i);
      const dateMatch = text.match(/(senin|selasa|rabu|kamis|jumat|sabtu|minggu)/i);
      
      if (timeMatch && dateMatch) {
        return {
          complete: true,
          data: {
            time: timeMatch[0],
            day: dateMatch[0]
          }
        };
      } else if (timeMatch) {
        return {
          complete: false,
          data: {},
          prompt: 'Hari apa? (Senin/Selasa/Rabu/Kamis/Jumat/Sabtu/Minggu)'
        };
      } else if (dateMatch) {
        return {
          complete: false,
          data: {},
          prompt: 'Jam berapa? (contoh: 15:00 atau 3 sore)'
        };
      }
      break;
      
    case 'setReminder':
      // Extract date/time information
      const dateTimeMatch = text.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})\s*(\d{1,2}):(\d{2})/);
      if (dateTimeMatch) {
        return {
          complete: true,
          data: {
            dueDate: `${dateTimeMatch[3]}-${dateTimeMatch[2]}-${dateTimeMatch[1]}T${dateTimeMatch[4]}:${dateTimeMatch[5]}:00`
          }
        };
      }
      break;
  }
  
  return {
    complete: false,
    data: {},
    prompt: 'Maaf, saya tidak mengerti. Bisa dijelaskan lebih detail?'
  };
}

async function updateContext(jid: string, pendingAction: any): Promise<void> {
  const context = getData('context');
  const now = Date.now();
  
  context[jid] = {
    jid,
    lastMessage: pendingAction?.params?.originalText || '',
    pendingAction,
    timestamp: now
  };
  
  // Clean old contexts (older than 1 hour)
  const oneHourAgo = now - (60 * 60 * 1000);
  Object.keys(context).forEach(key => {
    if (context[key].timestamp < oneHourAgo) {
      delete context[key];
    }
  });
  
  await saveData('context', context);
}
