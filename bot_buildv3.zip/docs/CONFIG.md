# ⚙️ Konfigurasi & Environment

## 🌍 ENV Variables
- `GEMINI_API_KEY` — kunci utama Gemini API.
- `GEMINI_API_KEY_1..N` — kunci tambahan untuk rotasi otomatis ketika 429.
- `TZ=Asia/Jakarta` — timezone default (WIB).
- `GROUP_JID=...@g.us` — grup default untuk mention-all / broadcast.
- `BOT_NAME` — nama bot (default: Aizen).
- `BOT_TRIGGERS` — daftar variasi pemanggil bot (dipisah koma).
- `ALLOWED_GROUPS`, `ALLOWED_DMS` — whitelist JID untuk membatasi akses (opsional).
- `HYDRATION_DAILY_GOAL_ML`, `HYDRATION_GLASS_SIZE_ML` — target hidrasi default.
- `NOTE_TAKERS` — daftar JID yang akan di-DM untuk koleksi materi harian.

Contoh `.env`:
```
GEMINI_API_KEY=...
GEMINI_API_KEY_1=...
GEMINI_API_KEY_2=...
TZ=Asia/Jakarta
GROUP_JID=1203...@g.us
BOT_NAME=Aizen
BOT_TRIGGERS=zen,aizen,zennn,zeen,zzzznnn
```

## 🧾 Skema JSON (Ringkas)
### schedule.json
```json
{
  "timezone": "Asia/Jakarta",
  "days": { "Mon": [], "Tue": [], "Wed": [], "Thu": [], "Fri": [], "Sat": [], "Sun": [] },
  "overrides": [
    { "date": "2025-08-25", "course": "Tekdig", "start": "17:00", "end": "19:00", "room": "LAB-3", "reason": "pindah sementara" }
  ]
}
```

### materials/index.json
```json
{
  "byDate": {
    "2025-08-22": [
      {
        "id": "mat_123",
        "course": "Medan Elektromagnetik",
        "dateISO": "2025-08-22",
        "captions": ["pengantar, DOT, cross, determinan"],
        "files": [ { "path": "storage/medan/2025-08-22/board.jpg", "mime": "image/jpeg" } ]
      }
    ]
  }
}
```

### hydration.json
```json
{ "dailyGoalMl": 2000, "glassSizeMl": 250 }
```

### aiState.json
```json
{ "keyIndex": 0 }
```

[🔙 Kembali ke README](../README.md)
