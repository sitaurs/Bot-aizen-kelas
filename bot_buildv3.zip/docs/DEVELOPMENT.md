# Development Guide

## Scripts
- `npm run dev` – run with tsx + nodemon
- `npm run build` – compile TypeScript to `dist/`
- `npm start` – run `dist/index.js`
- `npm run test:ai` – run conversation tests (uses live Gemini API)

## Testing
- Conversation tests: `tests/ai-conversation.ts`
  - Throttled with sleep/backoff
  - Logs called tools and replies
  - Use `.env` keys rotation to reduce 429

## API Key Rotation
- Put keys in `.env` as `GEMINI_API_KEY` and/or `GEMINI_API_KEY_1..N`.
- Active index persisted in `data/aiState.json` (field `keyIndex`).
- On 429, bot rotates to next key and retries once.

## Clarify Loop
- Model-led: tool `askClarify(question, expect)` lets the model ask.
- App-led: handlers validate required slots; if missing, ask one short question.

## Coding Style
- TypeScript strict mode, ESM imports.
- Logger: `pino` in pretty mode.

[Back to README](../README.md)
