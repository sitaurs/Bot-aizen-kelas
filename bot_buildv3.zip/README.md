# WhatsApp Class Manager Bot — Aizen ✨

Aizen adalah bot WhatsApp untuk manajemen kelas berbasis Node.js (TypeScript + ESM), Baileys (WhatsApp Web), dan Google Gemini API (`gemini-2.5-flash`). Bot ini siap produksi, data disimpan di JSON (tanpa database), mendukung Function Calling (tools) dengan clarify loop (tanya balik), penjadwalan (cron), kolektor materi, mention-all, fuzzy trigger nama bot, serta rotasi API key yang persisten.

## 🧭 Navigasi Cepat
- 📚 [Fitur](FEATURES.md)
- 📈 [Progress](PROGRESS.md)
- 🧩 [Arsitektur Teknis](docs/ARCHITECTURE.md)
- ⚙️ [Konfigurasi & Environment](docs/CONFIG.md)
- 🛠️ [Panduan Pengembangan](docs/DEVELOPMENT.md)
- 🆘 [Troubleshooting](TROUBLESHOOTING.md)

---

## ⭐ Highlight Kemampuan
- 🤖 AI Function-Calling (Gemini): tools mode AUTO, hasil natural, parameter tervalidasi.
- 🧠 Clarify Loop (tanya balik): model-led (`askClarify`) & app-led (slot filling per intent).
- 🗓️ Jadwal & Lokasi Kelas: dukung tanggal relatif ("hari ini", "besok", "Senin").
- ⏰ Pengingat: tugas, ujian (UTS/UAS/Quiz), kas, barang bawaan (set/hapus, hapus “terakhir”).
- 📦 Materi Kuliah: simpan media + caption per tanggal & matkul; cari kembali dengan query.
- 👥 Mention-All: `@ll` untuk mention semua partisipan (default `GROUP_JID`).
- 🧲 Fuzzy Trigger: variasi "zen/aizen/zennn/..." dipahami.
- 🕒 Cron Reminders (WIB): ringkasan pagi, T-15 sebelum kelas, barang bawaan malam/pagi, hidrasi.
- 💾 JSON-only: `data/` + file materi di `storage/`.
- 🔁 Rotasi API Key: dukung banyak key, rotasi otomatis saat 429, indeks rotasi disimpan di `data/aiState.json`.

---

## 🏗️ Arsitektur Singkat
```
src/
  ai/
    gemini.ts   # Integrasi Gemini + rotasi API + prompt sistem + clarify + retry
    tools.ts    # Deklarasi tools + router function-calling + handler fitur
  features/
    fuzzy-trigger.ts  # Deteksi nama bot (regex variasi)
    materials.ts      # Simpan/kirim materi & pencarian index
    mentions.ts       # Mention-all (@ll)
    nlu.ts            # (placeholder) konteks & klarifikasi lanjutan
  scheduler/
    cron.ts     # Cron jobs (WIB): ringkasan pagi, T-15, barang bawaan, hidrasi
  storage/
    files.ts    # Load/Save JSON + cache + ensure dirs
    local.ts    # Penyimpanan file lokal (buffer -> storage/...)
  utils/
    time.ts     # Dayjs + timezone WIB + normalisasi tanggal relatif
    logger.ts   # Pino logger (pretty)
    id.ts       # Generator ID (uuid)
    access.ts   # Whitelist grup/DM (opsional)
  wa/
    connect.ts  # Baileys connect (QR + pairing) + events + reauth
    handlers.ts # Routing pesan masuk + ekstraksi teks/media + akses kontrol
  index.ts      # Entry point: init data, AI, WA, cron
```
Lebih detail 👉 [Arsitektur Teknis](docs/ARCHITECTURE.md)

---

## 🧾 Model Data (Ringkas)
- `schedule.json`: `{ timezone, days: {Mon..Sun: Class[]}, overrides: ScheduleOverride[] }`
- `lecturers.json`: daftar dosen `{ id, name, phone, email, courses[] }`
- `reminders.json`, `exams.json`, `cashReminders.json`: daftar entri `{ id, ... }`
- `items.json`: `{ [course: string]: string[] }`
- `materials/index.json`: `{ byDate: { [YYYY-MM-DD]: MaterialEntry[] } }`
- `hydration.json`: `{ dailyGoalMl, glassSizeMl }`
- `aiState.json`: `{ keyIndex }` (indeks API key aktif untuk rotasi)
Lebih detail 👉 [Konfigurasi & ENV + Skema JSON](docs/CONFIG.md)

---

## 🚀 Setup Cepat
1) Persyaratan
- Node.js >= 20
- Akun WhatsApp
- Google Gemini API key(s)

2) Instalasi
```bash
npm install
cp env.example .env
```

3) Konfigurasi `.env`
```
GEMINI_API_KEY=...
# (Opsional, rotasi — boleh menambah banyak)
GEMINI_API_KEY_1=...
GEMINI_API_KEY_2=...
...
TZ=Asia/Jakarta
GROUP_JID=1203...@g.us
BOT_NAME=Aizen
BOT_TRIGGERS=zen,aizen,zennn,zeen,zzzznnn
```

4) Menjalankan (dev)
```bash
npm run dev
```
Scan QR / gunakan pairing code untuk login.

5) Build & Start (prod)
```bash
npm run build
npm start
```
Panduan lanjut 👉 [Panduan Pengembangan](docs/DEVELOPMENT.md)

---

## 💬 Contoh Percakapan
- Jadwal hari ini
  - Kamu: "zen jadwal hari ini apa?"
  - Bot: (panggil `getTodayInfo` + `getSchedule`) → ringkas jadwal
- Ubah jadwal
  - Kamu: "zen pindahin EM ke Senin 17:00–19:00 di B201"
  - Bot: (jika tanggal belum jelas) tanya balik; jika cukup → `changeSchedule`
- Pengingat tugas
  - Kamu: "zen set reminder tugas EM Jumat 30 Agustus jam 17:00"
  - Bot: `setReminder` → konfirmasi natural
- Materi
  - Kamu: "zen ada pembahasan vektor ga?"
  - Bot: `queryMaterials` → kirim daftar/temuan
- Mention semua
  - Kamu: "@ll besok kumpul jam 7"
  - Bot: ambil partisipan grup → `mentions`

Lebih lengkap 👉 [Fitur & Tool Mapping](FEATURES.md)

---

## 🧩 Function-Calling & Klarifikasi
- Alur FC: model → `functionCall(name,args)` → handler → `functionResponse { name, response }` → model rangkai jawaban natural.
- Klarifikasi:
  - App-led: handler cek slot wajib (mis. `course/start/end`) → jika kurang, tanya 1 hal paling penting.
  - Model-led: tool `askClarify(question, expect)` untuk pertanyaan natural.
- Tanggal relatif: "hari ini", "besok", nama hari → dipetakan ke tanggal Asia/Jakarta.

---

## 🔁 Rotasi API Key (Anti 429)
- Isi `.env` dengan `GEMINI_API_KEY` dan/atau `GEMINI_API_KEY_1..N`.
- Saat 429: Aizen rotasi ke key berikutnya dan retry otomatis.
- Indeks aktif disimpan di `data/aiState.json` → bertahan saat restart.

---

## 🧪 Pengujian
- `npm run test:ai` → skenario percakapan (live API)
- Terdapat throttling + backoff otomatis untuk mengurangi 429
- Gunakan beberapa API key (rotasi) agar pengujian lebih lancar

Hasil & log akan menampilkan `tool.start`/`tool.success` + ringkasan pass/fail.

---

## 📦 Deployment (Ringkas)
- PM2: lihat `ecosystem.config.js`
- Systemd: jalankan `npm run build` → `npm start` sebagai service
- Simpan `.env` & `auth/` (kredensial WA) dengan aman

---

## ⚠️ Etika & Kepatuhan
- Baileys bukan API resmi WhatsApp → gunakan bertanggung jawab, hindari spam/mass messaging.
- Hargai privasi data; batasi akses grup/DM dengan whitelist.

---

Silakan jelajahi:
- 📚 [Fitur](FEATURES.md)
- 🧩 [Arsitektur](docs/ARCHITECTURE.md)
- ⚙️ [Konfigurasi](docs/CONFIG.md)
- 🛠️ [Pengembangan](docs/DEVELOPMENT.md)
- 🆘 [Troubleshooting](TROUBLESHOOTING.md)

[⬆️ Kembali ke atas](README.md)


<!-- TEST_RESULTS_START -->

# Automated Feature Tests

Total: 10/10 passed

- ✅ Access control - groups allow/deny
- ✅ Access control - DMs allow/deny & note takers
- ✅ Fuzzy trigger detection
- ✅ Mention all builds mentions list
- ✅ Tools: getSchedule & changeSchedule
- ✅ Tools: set/delete reminder
- ✅ Tools: set/delete exam
- ✅ Tools: carry items set/delete
- ✅ Lecturer contact & class location
- ✅ Materials: saveIncomingMedia + search + send

<!-- TEST_RESULTS_END -->
