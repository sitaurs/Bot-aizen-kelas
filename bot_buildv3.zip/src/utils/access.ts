import { getData } from '../storage/files.js';

function parseList(envValue?: string): string[] {
  return (envValue || '')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);
}

export function getAllowedGroupJids(): string[] {
  const groups = new Set<string>();
  const fromEnv = parseList(process.env.ALLOWED_GROUPS);
  fromEnv.forEach(j => groups.add(j));
  const main = process.env.GROUP_JID;
  if (main) groups.add(main);
  return Array.from(groups);
}

export function getAllowedDmJids(): string[] {
  const list = new Set<string>();
  parseList(process.env.ALLOWED_DMS).forEach(j => list.add(j));
  // Include note takers from JSON data
  try {
    const noteTakers: string[] = getData('noteTakers') || [];
    noteTakers.forEach(j => list.add(j));
  } catch {}
  return Array.from(list);
}

export function isAllowedChat(jid: string): boolean {
  const isGroup = jid.endsWith('@g.us');
  if (isGroup) {
    return getAllowedGroupJids().includes(jid);
  }
  return getAllowedDmJids().includes(jid);
}


