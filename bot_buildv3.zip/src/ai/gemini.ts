import { GoogleGenAI, FunctionCallingConfigMode } from '@google/genai';
import { getData, saveData } from '../storage/files.js';
import { logger } from '../utils/logger.js';
import { tools, handleToolCall } from './tools.js';

export class GeminiAI {
  private ai: GoogleGenAI;
  private apiKeys: string[] = [];
  private currentKeyIndex = 0;
  private model: any;

  constructor() {
    this.apiKeys = this.loadApiKeys();
    if (this.apiKeys.length === 0) throw new Error('No GEMINI_API_KEY provided');
    this.currentKeyIndex = this.restoreKeyIndex();
    this.ai = new GoogleGenAI({ apiKey: this.apiKeys[this.currentKeyIndex]! });
    this.model = this.ai.models.generateContent;
    logger.info({ keyIndex: this.currentKeyIndex + 1, total: this.apiKeys.length, keyEnd: this.apiKeys[this.currentKeyIndex]!.slice(-7) }, 'gemini.initKey');
  }

  private loadApiKeys(): string[] {
    const seen = new Set<string>();
    const add = (v?: string) => { if (v && v.trim()) seen.add(v.trim()); };
    add(process.env.GEMINI_API_KEY);
    const csv = process.env.GEMINI_API_KEYS || process.env.GEMINI_KEYS;
    if (csv) {
      csv.split(/[\s,;]+/).map(s => s.trim()).filter(Boolean).forEach(k => add(k));
    }
    for (let i = 1; i <= 50; i++) add(process.env[`GEMINI_API_KEY_${i}`]);
    const arr = Array.from(seen);
    logger.info({ keysCount: arr.length }, 'gemini.keysLoaded');
    return arr;
  }

  private restoreKeyIndex(): number {
    try {
      const state = getData('aiState') || { keyIndex: 0 };
      return Math.min(Math.max(0, state.keyIndex || 0), Math.max(0, this.apiKeys.length - 1));
    } catch { return 0; }
  }

  private async persistKeyIndex(index: number) {
    const state = getData('aiState') || {};
    state.keyIndex = index;
    await saveData('aiState', state);
  }

  private async rotateKey() {
    if (this.apiKeys.length <= 1) return; // nothing to rotate
    this.currentKeyIndex = (this.currentKeyIndex + 1) % this.apiKeys.length;
    await this.persistKeyIndex(this.currentKeyIndex);
    this.ai = new GoogleGenAI({ apiKey: this.apiKeys[this.currentKeyIndex]! });
    this.model = this.ai.models.generateContent;
    logger.warn({ keyIndex: this.currentKeyIndex + 1, total: this.apiKeys.length, keyEnd: this.apiKeys[this.currentKeyIndex]!.slice(-7) }, 'gemini.rotateKey');
  }

  async chatAndAct(text: string, context?: string): Promise<string> {
    try {
      const rotateEach = (process.env.GEMINI_ROTATE_EACH === '1') || (process.env.GEMINI_ROTATE_MODE === 'each');
      if (rotateEach) {
        await this.rotateKey();
      }
      const systemPrompt = `Kamu adalah asisten kelas bernama ${process.env.BOT_NAME || 'Aizen'}, bot kelas D4 Jaringan Komunikasi Digital.
Peran: jadwal & lokasi kelas, materi (simpan/cari), kontak dosen, pengingat (tugas/ujian/kas/barang), mention-all, hidrasi.
Gaya: santai, singkat, paham slang. Jangan menyebut user sebagai "Zen"; itu nama bot lama.
Panggilan: ${process.env.BOT_TRIGGERS || 'zen,aizen,zennn,zeen,zzzznnn'}.
Waktu: Asia/Jakarta. Untuk pertanyaan tanggal/hari ("hari ini", "sekarang tanggal berapa"), panggil tool getTodayInfo dan gunakan hasilnya.
Function-calling: SELALU gunakan tools untuk melakukan aksi CRUD data. Jika user bilang "terakhir" (hapus terbaru) tanpa ID, panggil deleteCashReminder/deleteExam tanpa id.
Mention-all: jika user pakai "@ll" atau minta mention semua, panggil mentionAll bahkan tanpa JID (pakai default dari sistem). 
Clarify loop: jika argumen kurang, tanya satu hal terpenting saja, lalu lanjutkan.
PENTING: Jika user bertanya jadwal (hari ini/besok/hari X/minggu depan), panggil getSchedule (gunakan dayName atau date). Jangan membuat jadwal kreatif/filosofis; selalu gunakan data jadwal. Untuk lokasi kelas, panggil getClassLocation.

FORMAT PESAN: Gunakan format WhatsApp yang benar dan menarik:
- *teks tebal* untuk judul mata kuliah dan nama dosen
- _teks miring_ untuk waktu dan ruangan
- 📚🎓⏰🏢👨‍🏫👩‍🏫 untuk emoji yang relevan
- Gunakan bullet points (-) untuk daftar
- Buat pesan yang informatif tapi tidak hambar
- Contoh: "📚 *Sistem Komunikasi Fiber Optik*\\n⏰ _09:30-12:00_ | 🏢 _AH.1.10_\\n👨‍🏫 *Drs. Yoyok Heru P. I., M.T.*\\n📱 628123314531"`;

      const messages = [
        { role: 'user', parts: [{ text: systemPrompt }] },
        { role: 'user', parts: [{ text }] }
      ];

      if (context) {
        messages.push({ role: 'user', parts: [{ text: `Context sebelumnya: ${context}` }] });
      }

      const doGenerate = async (payloadContents: any) => {
        logger.info({ keyIndex: this.currentKeyIndex + 1, total: this.apiKeys.length, keyEnd: this.apiKeys[this.currentKeyIndex]!.slice(-7) }, 'gemini.request');
        return this.model({
          model: 'gemini-2.5-flash',
          contents: payloadContents,
          config: {
            tools: [{ functionDeclarations: tools }],
            toolConfig: { functionCallingConfig: { mode: FunctionCallingConfigMode.AUTO } }
          }
        });
      };

      const backoffGenerate = async (payloadContents: any) => {
        try {
          return await doGenerate(payloadContents);
        } catch (e: any) {
          if (String(e?.message || '').includes('429')) {
            await this.rotateKey();
            return await doGenerate(payloadContents);
          }
          throw e;
        }
      };

      let response: any = await backoffGenerate(messages);

      // Multi-call loop (max 5 turns)
      let turns = 0;
      while (turns++ < 5) {
        const functionCalls = response.functionCalls;
        if (!functionCalls || functionCalls.length === 0) break;
        const functionCall = functionCalls[0];
        logger.info(`Function call: ${functionCall.name}`, functionCall.args);
        let args: any = functionCall.args;
        if (typeof args === 'string') {
          try { args = JSON.parse(args); } catch {}
        }
        const toolResult = await handleToolCall({ name: functionCall.name, args });
        const followupPayload = [
          { role: 'user', parts: [{ text }] },
          { role: 'model', parts: [{ functionCall: { name: functionCall.name, args } }] },
          { role: 'user', parts: [{ functionResponse: { name: functionCall.name, response: toolResult } }] }
        ];
        if (rotateEach) {
          await this.rotateKey();
        }
        response = await backoffGenerate(followupPayload);
      }

      return response.text || 'Maaf, saya tidak mengerti permintaan Anda.';
    } catch (error) {
      logger.error('Error in Gemini AI:', error as any);
      return 'Maaf, terjadi kesalahan dalam memproses permintaan Anda.';
    }
  }

  async generateResponse(text: string): Promise<string> {
    try {
      const response = await this.model({
        model: 'gemini-2.5-flash',
        contents: [{ role: 'user', parts: [{ text }] }]
      });

      return response.text || 'Maaf, saya tidak dapat memberikan respons.';
    } catch (error) {
      logger.error('Error generating response:', error as any);
      return 'Maaf, terjadi kesalahan.';
    }
  }
}

export default GeminiAI;
