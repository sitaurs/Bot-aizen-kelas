import { readFile } from 'fs/promises';
import { getData, saveData } from './files.js';

export type Lecturer = { code: number; name: string; wa: string; waJid: string };
export type EnrichedClass = { course: string; start: string; end: string; room: string | null; lecturer: Lecturer };
export type DayKey = 'senin' | 'selasa' | 'rabu' | 'kamis' | 'jumat';
export type DayMap = Record<DayKey, EnrichedClass[]>;

function toWaJid(wa: string): string { return `${wa}@s.whatsapp.net`; }

async function parseFirstJsonObject(path: string): Promise<any | null> {
  try {
    const txt = await readFile(path, 'utf8');
    let depth = 0;
    let start = -1;
    for (let i = 0; i < txt.length; i++) {
      const ch = txt[i];
      if (ch === '{') { if (start === -1) start = i; depth++; }
      else if (ch === '}') { depth--; if (depth === 0 && start !== -1) { const s = txt.slice(start, i + 1); return JSON.parse(s); } }
    }
    return null;
  } catch { return null; }
}

export async function buildEnrichedSchedule(): Promise<DayMap> {
  let rawLecturers: any = getData('lecturers') || {};
  let rawSchedule: any = getData('schedule') || {};
  let byCode: Record<string, any> = (rawLecturers.byCode || {}) as any;

  if (!byCode || Object.keys(byCode).length === 0) {
    const first = await parseFirstJsonObject('data/lecturers.json');
    if (first && first.byCode) byCode = first.byCode;
  }

  let idDays: Record<string, any[]> | null = (rawSchedule.days && rawSchedule.days.senin) ? rawSchedule.days : null;
  if (!idDays) {
    const first = await parseFirstJsonObject('data/schedule.json');
    if (first && first.days && first.days.senin) idDays = first.days;
  }

  const days: DayMap = { senin: [], selasa: [], rabu: [], kamis: [], jumat: [] };
  for (const day of Object.keys(days) as DayKey[]) {
    const entries = ((idDays && (idDays as any)[day]) || []) as any[];
    const seen = new Set<string>();
    for (const cls of entries) {
      const key = `${(cls.course || '').toLowerCase()}|${cls.start}|${cls.end}`;
      if (seen.has(key)) continue; // dedup
      seen.add(key);
      const code = String(cls.lecturerCode);
      const lec = byCode[code];
      if (!lec) continue;
      const wa = String(lec.wa).replace(/\D/g, '').replace(/^0/, '62');
      const enriched: EnrichedClass = {
        course: cls.course,
        start: cls.start,
        end: cls.end,
        room: cls.room ?? null,
        lecturer: { code: Number(code), name: lec.name, wa, waJid: toWaJid(wa) }
      };
      days[day].push(enriched);
    }
  }
  await saveData('enrichedSchedule', days);
  return days;
}

export function findLecturerByCourse(enriched: DayMap, course: string): Lecturer | null {
  const needle = course.toLowerCase();
  const syn = [needle, needle.replace(/komunikasi/,'kom').replace(/mikrokontroler/,'mcu')];
  for (const day of Object.keys(enriched) as DayKey[]) {
    for (const cls of enriched[day]) {
      const c = cls.course.toLowerCase();
      if (syn.some(s => c.includes(s))) return cls.lecturer;
    }
  }
  return null;
}
