# Automated Feature Tests

Total: 10/10 passed

- ✅ Access control - groups allow/deny
- ✅ Access control - DMs allow/deny & note takers
- ✅ Fuzzy trigger detection
- ✅ Mention all builds mentions list
- ✅ Tools: getSchedule & changeSchedule
- ✅ Tools: set/delete reminder
- ✅ Tools: set/delete exam
- ✅ Tools: carry items set/delete
- ✅ Lecturer contact & class location
- ✅ Materials: saveIncomingMedia + search + send
