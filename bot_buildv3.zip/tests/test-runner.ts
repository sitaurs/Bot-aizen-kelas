/*
  Simple test runner that validates major features without hitting network.
  Run with: npm run test:bot
*/
import 'dotenv/config';
import { readFile, writeFile, mkdir, stat, rm } from 'fs/promises';
import { existsSync } from 'fs';
import { join } from 'path';

import { getData, saveData, loadAllData, updateData, ensureCourseDir } from '../src/storage/files.js';
import { fuzzyTrigger } from '../src/features/fuzzy-trigger.js';
import { handleMentionAll } from '../src/features/mentions.js';
import { saveIncomingMedia, searchMaterials, sendMaterialToChat } from '../src/features/materials.js';
import { tools, handleToolCall } from '../src/ai/tools.js';
import { getAllowedGroupJids, getAllowedDmJids, isAllowedChat } from '../src/utils/access.js';

type TestFn = () => Promise<void> | void;
interface TestCase { name: string; fn: TestFn }

const RESULTS: { name: string; ok: boolean; info?: string }[] = [];
async function test(name: string, fn: TestFn) {
  try {
    await fn();
    RESULTS.push({ name, ok: true });
  } catch (err: any) {
    RESULTS.push({ name, ok: false, info: err?.message || String(err) });
  }
}

// Mock WASocket minimal
class MockSock {
  public sent: any[] = [];
  public participants: string[];
  constructor(participants: string[] = []) { this.participants = participants }
  async sendMessage(jid: string, content: any) {
    this.sent.push({ jid, content });
  }
  async groupMetadata(jid: string) {
    return { id: jid, subject: 'Test Group', participants: this.participants.map(id => ({ id })) } as any;
  }
  async updateMediaMessage(m: any) { return m; }
}

async function backup(path: string): Promise<string | null> {
  try {
    const content = await readFile(path, 'utf8');
    return content;
  } catch {
    return null;
  }
}

async function restore(path: string, backupContent: string | null) {
  if (backupContent === null) return;
  await writeFile(path, backupContent, 'utf8');
}

async function main() {
  // Prepare env for tests
  process.env.GROUP_JID = '12345@g.us';
  process.env.ALLOWED_GROUPS = '12345@g.us';
  process.env.ALLOWED_DMS = '1111@s.whatsapp.net,2222@s.whatsapp.net';

  await loadAllData();

  // Backup critical data files
  const files = [
    'data/schedule.json',
    'data/lecturers.json',
    'data/items.json',
    'data/reminders.json',
    'data/noteTakers.json',
    'data/exams.json',
    'data/cashReminders.json',
    'data/materials/index.json',
    'data/context.json'
  ];
  const backups: Record<string, string | null> = {};
  for (const f of files) backups[f] = await backup(f);

  // Seed some data ensuring presence
  await updateData('noteTakers', () => ['3333@s.whatsapp.net']);
  await updateData('exams', () => []);
  await updateData('cashReminders', () => []);
  await updateData('lecturers', () => [
    { id: 'em001', name: 'Dr. Ir. Nama Dosen, S.T., M.T.', phone: '+6281111', courses: ['Medan Elektromagnetik'] }
  ]);
  await updateData('schedule', (s: any) => ({
    timezone: 'Asia/Jakarta',
    days: { Mon: [{ course: 'Medan Elektromagnetik', start: '08:00', end: '10:00', room: 'B-201', lecturerId: 'em001' }], Tue: [], Wed: [], Thu: [], Fri: [], Sat: [], Sun: [] },
    overrides: []
  }));
  await updateData('items', () => ({ 'Medan Elektromagnetik': ['kalkulator', 'buku catatan'] }));
  await updateData('materials', () => ({ byDate: {} }));
  await updateData('reminders', () => []);

  // Tests
  await test('Access control - groups allow/deny', () => {
    const allowed = getAllowedGroupJids();
    if (!allowed.includes('12345@g.us')) throw new Error('main group not allowed');
    if (isAllowedChat('999@g.us')) throw new Error('unexpected allow for other group');
  });

  await test('Access control - DMs allow/deny & note takers', () => {
    if (!isAllowedChat('1111@s.whatsapp.net')) throw new Error('allowed DM not whitelisted');
    if (!isAllowedChat('3333@s.whatsapp.net')) throw new Error('note taker DM not allowed');
    if (isAllowedChat('9999@s.whatsapp.net')) throw new Error('unexpected allow for unknown DM');
  });

  await test('Fuzzy trigger detection', () => {
    const cases = ['zen', 'aizen', 'zeeeen', 'zzzznnn', 'random'];
    const expected = [true, true, true, true, false];
    cases.forEach((t, i) => {
      const got = fuzzyTrigger(t);
      if (got !== expected[i]) throw new Error(`fuzzy failed for ${t}`);
    });
  });

  await test('Mention all builds mentions list', async () => {
    const sock = new MockSock(['111@s.whatsapp.net', '222@s.whatsapp.net']);
    await handleMentionAll({ sock: sock as any, jid: '12345@g.us', text: 'Besok kumpul 7' });
    if (sock.sent.length !== 1) throw new Error('no message sent');
    const m = sock.sent[0].content;
    if (!m.mentions || m.mentions.length !== 2) throw new Error('mentions missing');
  });

  await test('Tools: getSchedule & changeSchedule', async () => {
    const res1 = await handleToolCall({ name: 'getSchedule', args: { dayName: 'Mon', date: '2025-08-25' } });
    if (res1.totalClasses < 1) throw new Error('getSchedule empty');
    const res2 = await handleToolCall({ name: 'changeSchedule', args: { course: 'Tekdig', date: '2025-08-25', start: '17:00', end: '19:00', room: 'LAB-3', reason: 'pindah sementara' } });
    if (!res2.success) throw new Error('changeSchedule failed');
  });

  await test('Tools: set/delete reminder', async () => {
    const add = await handleToolCall({ name: 'setReminder', args: { type: 'task', title: 'Tugas EM', dueISO: '2025-09-01T17:00:00', course: 'Medan Elektromagnetik' } });
    if (!add.success) throw new Error('setReminder failed');
    const id = add.id;
    const del = await handleToolCall({ name: 'deleteReminder', args: { id } });
    if (!del.success) throw new Error('deleteReminder failed');
  });

  await test('Tools: set/delete exam', async () => {
    const add = await handleToolCall({ name: 'setExam', args: { course: 'Medan Elektromagnetik', type: 'UTS', dateISO: '2025-09-10', start: '09:00', end: '11:00', room: 'A-101' } });
    if (!add.success) throw new Error('setExam failed');
    const id = add.id;
    const del = await handleToolCall({ name: 'deleteExam', args: { id } });
    if (!del.success) throw new Error('deleteExam failed');
  });

  await test('Tools: carry items set/delete', async () => {
    const set = await handleToolCall({ name: 'setCarryItem', args: { course: 'Medan Elektromagnetik', items: ['kalkulator', 'penggaris'] } });
    if (!set.success) throw new Error('setCarryItem failed');
    const delPartial = await handleToolCall({ name: 'deleteCarryItem', args: { course: 'Medan Elektromagnetik', items: ['penggaris'] } });
    if (!delPartial.success) throw new Error('deleteCarryItem partial failed');
    const delAll = await handleToolCall({ name: 'deleteCarryItem', args: { course: 'Medan Elektromagnetik' } });
    if (!delAll.success) throw new Error('deleteCarryItem all failed');
  });

  await test('Lecturer contact & class location', async () => {
    const c = await handleToolCall({ name: 'getLecturerContact', args: { nameOrCourse: 'Medan' } });
    if (!c || !Array.isArray(c.lecturers) || c.lecturers.length < 1) throw new Error('lecturer not found');
    const loc = await handleToolCall({ name: 'getClassLocation', args: { course: 'Medan Elektromagnetik', dateISO: '2025-08-25' } });
    if (!loc.room) throw new Error('class location missing');
  });

  await test('Materials: saveIncomingMedia + search + send', async () => {
    const course = 'Medan Elektromagnetik';
    const date = '2025-08-22';
    const dir = await ensureCourseDir(course, date);
    const buf = Buffer.from('testdata');
    await saveIncomingMedia({
      sock: new MockSock() as any,
      msg: { key: { remoteJid: '3333@s.whatsapp.net', fromMe: false }, message: {}, messageTimestamp: Date.now() } as any,
      buffer: buf,
      filename: 'board.jpg',
      caption: 'pembahasan vector dan dot product',
      mediaType: 'image'
    });
    const found = await searchMaterials('vector');
    if (!Array.isArray(found) || found.length < 1) throw new Error('searchMaterials failed');
    const sock = new MockSock();
    const sentOk = await sendMaterialToChat(sock as any, '1111@s.whatsapp.net', found[0].id);
    if (!sentOk) throw new Error('sendMaterialToChat failed');
  });

  // Summarize
  const pass = RESULTS.filter(r => r.ok).length;
  const total = RESULTS.length;
  const lines = RESULTS.map(r => `- ${r.ok ? '✅' : '❌'} ${r.name}${r.ok ? '' : ` — ${r.info}`}`);
  const summary = [`# Automated Feature Tests`, '', `Total: ${pass}/${total} passed`, '', ...lines, ''].join('\n');
  await writeFile('tests/TEST_RESULTS.md', summary, 'utf8');

  // Append to README (replace or add section)
  try {
    const readme = await readFile('README.md', 'utf8');
    const start = '<!-- TEST_RESULTS_START -->';
    const end = '<!-- TEST_RESULTS_END -->';
    const block = `${start}\n\n${summary}\n${end}`;
    let next: string;
    if (readme.includes(start) && readme.includes(end)) {
      next = readme.replace(new RegExp(`${start}[\s\S]*?${end}`, 'm'), block);
    } else {
      next = readme + '\n\n' + block + '\n';
    }
    await writeFile('README.md', next, 'utf8');
  } catch {}

  // Restore backups
  for (const f of files) await restore(f, backups[f]);

  // Print concise output
  console.log(`Passed ${pass}/${total}`);
  if (pass !== total) process.exit(1);
}

main().catch(e => { console.error(e); process.exit(1); });


