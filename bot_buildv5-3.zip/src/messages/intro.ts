// Deprecated: use buildIntroMessage() in src/features/intro.ts
export const INTRO_MESSAGE = `Ketik *!intro* untuk melihat info terbaru.`;


