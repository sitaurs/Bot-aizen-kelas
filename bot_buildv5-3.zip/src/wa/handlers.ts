import { WASocket, proto } from '@whiskeysockets/baileys';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { logger } from '../utils/logger.js';
import { fuzzyTrigger } from '../features/fuzzy-trigger.js';
// import { handleMentionAll } from '../features/mentions.js';
import { handleTagAll } from '../features/tagAll.js';
import { buildIntroMessage } from '../features/intro.js';
import { sendSystemTagAll } from '../features/tagAllSystem.js';
import { getData } from '../storage/files.js';
import { aiClarifyOrAct } from '../features/nlu.js';
import { saveIncomingMedia } from '../features/materials.js';
import { WhatsAppMessage } from '../types/index.js';
import { isAllowedChat, getPersonByJid, getFunRoleByJid } from '../utils/access.js';
import { maybeAppendQuote } from '../utils/quotes.js';

interface MessageUpsertParams {
  sock: WASocket;
  upsert: {
    messages: WhatsAppMessage[];
    type: 'notify' | 'append';
  };
}

export async function onMessageUpsert({ sock, upsert }: MessageUpsertParams): Promise<void> {
  const msg = upsert.messages?.[0];
  
  if (!msg?.message || msg.key.fromMe) {
    return;
  }

  const jid = msg.key.remoteJid!;
  // Access control: ignore messages outside allowed groups/DMs
  if (!isAllowedChat(jid)) {
    return;
  }
  const text = extractText(msg);
  
  if (!text) {
    // Handle media messages
    await handleMediaMessage(sock, msg, jid);
    return;
  }

  const person = getPersonByJid(jid);
  logger.info(`Message from ${jid}${person ? ` (${person.name})` : ''}: ${text}`);

  // Early bypass: @ll trigger without Gemini
  const isAllowedByRoles = async (senderJid: string, groupJid: string) => {
    const p: any = getPersonByJid(senderJid);
    const fun = p?.funRole || 'anak_baik';
    const core = p && Array.isArray(p.roles) && p.roles.some((r: string) => ['ketua_kelas','bendahara','sekretaris','developer'].includes(r));
    if (fun === 'anak_nakal' && !core) return false;
    return true;
  };
  if (await handleTagAll(sock, msg as any, String(text || '').trim(), { isAllowedByRoles, rateLimitMs: 2*60*1000, batchSize: 80 })) {
    return;
  }

  // Early bypass: !intro (no Gemini)
  if (String(text || '').trim() === '!intro') {
    const intro = await buildIntroMessage();
    const cfg = getData('config') || { tagAll: {} };
    if (jid.endsWith('@g.us') && cfg.tagAll?.intro) {
      await sendSystemTagAll(() => sock, jid, intro);
    } else {
      await sock.sendMessage(jid, { text: intro });
    }
    return;
  }

  // Handle @ll mention is unified via handleTagAll above. No fallback here.

  // Check for bot trigger
  if (fuzzyTrigger(text)) {
    const reply = await aiClarifyOrAct({ sock, msg, text });
    const withGreeting = person ? `Oke *${person.name}* 👋\n\n${reply}` : reply;
    const funRole = getFunRoleByJid(jid);
    const finalText = maybeAppendQuote(jid, withGreeting, funRole === 'anak_nakal');
    await sock.sendMessage(jid, { text: finalText });
  }
}

function extractText(msg: WhatsAppMessage): string | null {
  const message = msg.message;
  
  if (message.conversation) {
    return message.conversation;
  }
  
  if (message.extendedTextMessage) {
    return message.extendedTextMessage.text;
  }
  
  if (message.imageMessage?.caption) {
    return message.imageMessage.caption;
  }
  
  if (message.videoMessage?.caption) {
    return message.videoMessage.caption;
  }
  
  if (message.documentMessage?.caption) {
    return message.documentMessage.caption;
  }
  
  return null;
}

async function handleMediaMessage(sock: WASocket, msg: WhatsAppMessage, jid: string): Promise<void> {
  try {
    const message = msg.message;
    let mediaType: string | null = null;
    let filename: string | null = null;
    let caption: string | null = null;

    if (message.imageMessage) {
      mediaType = 'image';
      filename = message.imageMessage.fileName || `image_${Date.now()}.jpg`;
      caption = message.imageMessage.caption || null;
    } else if (message.videoMessage) {
      mediaType = 'video';
      filename = message.videoMessage.fileName || `video_${Date.now()}.mp4`;
      caption = message.videoMessage.caption || null;
    } else if (message.documentMessage) {
      mediaType = 'document';
      filename = message.documentMessage.fileName || `document_${Date.now()}`;
      caption = message.documentMessage.caption || null;
    } else if (message.audioMessage) {
      mediaType = 'audio';
      filename = `audio_${Date.now()}.ogg`;
    }

    if (mediaType) {
      logger.info(`Received ${mediaType} from ${jid}`);
      
      // Download and save media
      const buffer = await downloadMediaMessage(msg, 'buffer', {}, {
        reuploadRequest: sock.updateMediaMessage,
        logger: (console as any) // Baileys expects an ILogger; for simplicity use console
      } as any);

      // Save to materials if it's from a note taker
      const noteTakers = process.env.NOTE_TAKERS?.split(',') || [];
      if (noteTakers.includes(jid)) {
        await saveIncomingMedia({
          sock,
          msg,
          buffer,
          filename: filename || `file_${Date.now()}`,
          caption,
          mediaType
        });
        
        await sock.sendMessage(jid, { 
          text: `✅ Materi berhasil disimpan! ${caption ? `\nCaption: ${caption}` : ''}` 
        });
      }
    }
  } catch (error) {
    logger.error({ err: error as any }, 'Error handling media message');
  }
}

export async function sendMessage(sock: WASocket, jid: string, content: any): Promise<void> {
  try {
    await sock.sendMessage(jid, content);
  } catch (error) {
    logger.error({ err: error as any, jid, contentType: Object.keys(content)[0] }, 'Error sending message');
  }
}

export async function sendTextMessage(sock: WASocket, jid: string, text: string): Promise<void> {
  await sendMessage(sock, jid, { text });
}

export async function sendMediaMessage(
  sock: WASocket, 
  jid: string, 
  filePath: string, 
  caption?: string,
  type: 'image' | 'video' | 'document' = 'document'
): Promise<void> {
  try {
    const fs = await import('fs/promises');
    const buffer = await fs.readFile(filePath);
    
    let message: any = {};
    
    switch (type) {
      case 'image':
        message = {
          image: buffer,
          caption: caption || ''
        };
        break;
      case 'video':
        message = {
          video: buffer,
          caption: caption || ''
        };
        break;
      case 'document':
        message = {
          document: buffer,
          fileName: filePath.split('/').pop() || 'document',
          caption: caption || ''
        };
        break;
    }
    
    await sendMessage(sock, jid, message);
  } catch (error) {
    logger.error({ err: error as any, jid, filePath, type }, 'Error sending media message');
  }
}
