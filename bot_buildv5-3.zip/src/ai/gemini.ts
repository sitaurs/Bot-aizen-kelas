import { GoogleGenAI, FunctionCallingConfigMode } from '@google/genai';
import { getData, saveData } from '../storage/files.js';
import { logger } from '../utils/logger.js';
import { tools, handleToolCall } from './tools.js';

export class GeminiAI {
  private ai: GoogleGenAI;
  private apiKeys: string[] = [];
  private currentKeyIndex = 0;
  private model: any;
  private requesterJid?: string;

  constructor() {
    this.apiKeys = this.loadApiKeys();
    if (this.apiKeys.length === 0) throw new Error('No GEMINI_API_KEY provided');
    this.currentKeyIndex = this.restoreKeyIndex();
    this.ai = new GoogleGenAI({ apiKey: this.apiKeys[this.currentKeyIndex]! });
    this.model = this.ai.models.generateContent;
    logger.info({ keyIndex: this.currentKeyIndex + 1, total: this.apiKeys.length, keyEnd: this.apiKeys[this.currentKeyIndex]!.slice(-7) }, 'gemini.initKey');
  }

  setRequesterJid(jid: string) {
    this.requesterJid = jid;
  }

  private loadApiKeys(): string[] {
    const seen = new Set<string>();
    const add = (v?: string) => { if (v && v.trim()) seen.add(v.trim()); };
    add(process.env.GEMINI_API_KEY);
    const csv = process.env.GEMINI_API_KEYS || process.env.GEMINI_KEYS;
    if (csv) {
      csv.split(/[\s,;]+/).map(s => s.trim()).filter(Boolean).forEach(k => add(k));
    }
    for (let i = 1; i <= 50; i++) add(process.env[`GEMINI_API_KEY_${i}`]);
    const arr = Array.from(seen);
    logger.info({ keysCount: arr.length }, 'gemini.keysLoaded');
    return arr;
  }

  private restoreKeyIndex(): number {
    try {
      const state = getData('aiState') || { keyIndex: 0 };
      return Math.min(Math.max(0, state.keyIndex || 0), Math.max(0, this.apiKeys.length - 1));
    } catch { return 0; }
  }

  private async persistKeyIndex(index: number) {
    const state = getData('aiState') || {};
    state.keyIndex = index;
    await saveData('aiState', state);
  }

  private async rotateKey() {
    if (this.apiKeys.length <= 1) return; // nothing to rotate
    this.currentKeyIndex = (this.currentKeyIndex + 1) % this.apiKeys.length;
    await this.persistKeyIndex(this.currentKeyIndex);
    this.ai = new GoogleGenAI({ apiKey: this.apiKeys[this.currentKeyIndex]! });
    this.model = this.ai.models.generateContent;
    logger.warn({ keyIndex: this.currentKeyIndex + 1, total: this.apiKeys.length, keyEnd: this.apiKeys[this.currentKeyIndex]!.slice(-7) }, 'gemini.rotateKey');
  }

  async chatAndAct(text: string, context?: string): Promise<string> {
    try {
      const rotateEach = (process.env.GEMINI_ROTATE_EACH === '1') || (process.env.GEMINI_ROTATE_MODE === 'each');
      if (rotateEach) {
        await this.rotateKey();
      }
      const systemPrompt = `Kamu adalah asisten kelas bernama ${process.env.BOT_NAME || 'Aizen'} untuk D4 Jaringan Komunikasi Digital.
Gaya santai, singkat, paham slang. Timezone Asia/Jakarta. Panggilan: ${process.env.BOT_TRIGGERS || 'zen,aizen,zennn,zeen,zzzznnn'}.

- gunakan markdown whatsapp, gunakan * untuk bold, _ untuk italic, ~ untuk strikethrough. juga gunakan emoji relevan. juga gunakan elemen lainnya yang relevan seperti =, -, +, #, @, dan lainnya untuk menghias teks.
- anda bukan hanya asisten, anda juga sebagai teman, jadi jika user meminta hal yang tidak relevan, anda bisa menyarankan hal lain yang relevan.
FUNCTION CALLING (AUTO):
- SELALU gunakan tools untuk jadwal/dosen/materi/kelompok/reminder & CRUD data.
- JANGAN minta klarifikasi kalau maksud sudah cukup untuk memanggil tool; lengkapi yang wajar (mis. "Selasa"=DOW rabu/kamis dst sesuai konteks).
- Smalltalk/sapaan (halo, apa kabar, makasih, dll) balas ramah tanpa tools.
- Jika tool hasilnya kosong, JANGAN minta klarifikasi generik; beri saran format 1 kalimat atau alternatif kata kunci.
- Jika user bilang batal/cancel/reset, akhiri mode klarifikasi dan mulai baru.
- Setelah function call sukses, akhiri (jangan minta info lagi).
PRIORITAS REMINDER:
- Jika teks mengandung: "ingat", "ingetin", "reminder", "set reminder", "hapus reminder", "ubah reminder", "tunda reminder", "jadwalkan", "pengingat" → anggap tugas reminder, bukan pertanyaan jadwal.
- Kamu boleh memanggil tool jadwal lebih dulu untuk memahami detail (mis. "matkul kedua Senin"), tetapi aksi final harus create/update reminder, bukan mengirim daftar jadwal.
- Default jam jika tidak disebut: 07:00 WIB.
PANDUAN TOOLS:
- Jadwal: getTodayScheduleEnriched, getScheduleByDay({dayName:'senin|...'}), getWeeklySchedule({startISO,endISO})
- Dosen: getLecturerByCourse({courseQuery}), getLecturerInfo({name}) fallback ke by-course
- Materi: queryMaterials({query}) untuk pencarian; jika cocok, berikan daftar ringkas; kirim file kalau diminta
- Kelompok: makeRandomGroups({groupCount}) untuk "grum/grup acak N"
- Tanggal-hari: getTodayInfo jika perlu
- Reminder: createUniversalReminder, updateUniversalReminder, pauseReminder, resumeReminder, deleteReminder, listReminders, snoozeReminder.

FORMAT BALASAN:
- Gunakan *tebal* untuk judul/nama dosen, _miring_ untuk jam/ruang. Boleh pakai emoji relevan.

FEW-SHOTS:
User: "zen cari materi vektor"
Assistant: (CALL) queryMaterials({query:"vektor"}) → kirim ringkasan hasil.

User: "zen bentuk grum acak 5 anak"
Assistant: (CALL) makeRandomGroups({groupCount:5}) → tampilkan daftar kelompok.

User: "zen dosen mikro"
Assistant: (CALL) getLecturerByCourse({courseQuery:"mikro"}) → balas nama + wa.me.

User: "jadwal pekan ini zen"
Assistant: (CALL) getWeeklySchedule({startISO:"<senin>", endISO:"<minggu>"}).

User: "halo zen apa kabar"
Assistant: Balas ramah 1–4 kalimat tanpa tools.
User: "Zen Senin besok matkul kedua Senin besok yakni saluran transmisi itu harus sudah install Matlab/Octave dan CST Studio, jadi ingetin ya setiap hari"
Assistant: (CALL) getScheduleByDay({dayName:"senin"}) → (CALL) createUniversalReminder({ text:"Install Matlab/Octave dan CST Studio untuk Praktikum Saluran Transmisi & Gelombang Mikro", rrule:"FREQ=DAILY;BYHOUR=7;BYMINUTE=0", tags:["barang","software"] }) → Balas konfirmasi reminder (tanpa daftar jadwal).`;

      const messages = [
        { role: 'user', parts: [{ text: systemPrompt }] },
        { role: 'user', parts: [{ text }] }
      ];

      if (context) {
        messages.push({ role: 'user', parts: [{ text: `Context sebelumnya: ${context}` }] });
      }

      const doGenerate = async (payloadContents: any) => {
        logger.info({ keyIndex: this.currentKeyIndex + 1, total: this.apiKeys.length, keyEnd: this.apiKeys[this.currentKeyIndex]!.slice(-7) }, 'gemini.request');
        return this.model({
          model: 'gemini-2.5-flash',
          contents: payloadContents,
          config: {
            tools: [{ functionDeclarations: tools }],
            toolConfig: { functionCallingConfig: { mode: FunctionCallingConfigMode.AUTO } }
          }
        });
      };

      const sleep = (ms: number) => new Promise(res => setTimeout(res, ms));
      const backoffGenerate = async (payloadContents: any) => {
        let lastErr: any;
        for (let attempt = 0; attempt < 4; attempt++) {
          try {
            return await doGenerate(payloadContents);
          } catch (e: any) {
            lastErr = e;
            const msg = String(e?.message || e || '');
            const transient = /(429|INTERNAL|Internal|fetch failed|network|timeout|ETIMEDOUT|ENOTFOUND|ECONNRESET|socket hang)/i.test(msg);
            if (transient) {
              await this.rotateKey();
              const m = msg.match(/retryDelay"?:"?(\d+)s/);
              const secStr = (Array.isArray(m) && m[1]) ? m[1] : undefined;
              const delayMs = secStr ? (parseInt(secStr, 10) * 1000) : 1500 * (attempt + 1);
              await sleep(delayMs);
              continue;
            }
            throw e;
          }
        }
        throw lastErr;
      };

      let response: any = await backoffGenerate(messages);

      // Multi-call loop (max 5 turns)
      let turns = 0;
      while (turns++ < 5) {
        const functionCalls = response.functionCalls;
        if (!functionCalls || functionCalls.length === 0) break;
        const functionCall = functionCalls[0];
        logger.info(`Function call: ${functionCall.name}`, functionCall.args);
        let args: any = functionCall.args;
        if (typeof args === 'string') {
          try { args = JSON.parse(args); } catch {}
        }
        if (this.requesterJid && args && typeof args === 'object') {
          args._requesterJid = this.requesterJid;
        }
        const toolResult = await handleToolCall({ name: functionCall.name, args });
        const followupPayload = [
          { role: 'user', parts: [{ text }] },
          { role: 'model', parts: [{ functionCall: { name: functionCall.name, args } }] },
          { role: 'user', parts: [{ functionResponse: { name: functionCall.name, response: toolResult } }] }
        ];
        if (rotateEach) {
          await this.rotateKey();
        }
        response = await backoffGenerate(followupPayload);
      }

      return response.text || 'Maaf, saya tidak mengerti permintaan Anda.';
    } catch (error) {
      logger.error({ err: error as any, text, requesterJid: this.requesterJid }, 'Error in Gemini AI');
      
      // Log detailed error information
      if (error instanceof Error) {
        logger.error({ 
          message: error.message, 
          stack: error.stack,
          name: error.name 
        }, 'Detailed error info');
      }
      
      // Check for specific error types
      const errorMessage = String(error || '');
      if (/429|quota/i.test(errorMessage)) {
        return 'Maaf, API sedang sibuk. Coba lagi dalam beberapa saat.';
      } else if (/invalid|malformed/i.test(errorMessage)) {
        return 'Maaf, ada masalah dengan format permintaan. Coba lagi dengan kata yang lebih sederhana.';
      } else if (/timeout|network|fetch failed|ENOTFOUND|ECONNRESET/i.test(errorMessage)) {
        return 'Maaf, koneksi ke layanan AI terputus. Coba lagi sebentar.';
      }
      
      return 'Maaf, terjadi kesalahan dalam memproses permintaan Anda.';
    }
  }

  async generateResponse(text: string): Promise<string> {
    try {
      const response = await this.model({
        model: 'gemini-2.5-flash',
        contents: [{ role: 'user', parts: [{ text }] }]
      });

      return response.text || 'Maaf, saya tidak dapat memberikan respons.';
    } catch (error) {
      logger.error({ err: error as any, text }, 'Error generating response');
      return 'Maaf, terjadi kesalahan.';
    }
  }
}

export default GeminiAI;
