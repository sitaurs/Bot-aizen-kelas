# Gemini Conversation Tests

Total: 31/32 passed

- ✅ zen jadwal hari ini apa?
- ✅ zen jadwal besok apa?
- ✅ zen lokasi kelas EM hari ini dimana?
- ✅ zen pindahin EM ke Senin 17:00-19:00 di B201 karena bentrok
- ✅ zen ubah jadwal EM besok
- ✅ zen jadwal untuk rabu depan
- ✅ zen dimana kelas Tekdig minggu depan?
- ✅ zen set reminder tugas EM Jumat 30 Agustus jam 17:00
- ✅ zen set reminder kas 50000 tanggal 24 Agustus jam 17:00
- ✅ zen set UTS EM 10 September 2025 jam 09:00 sampai 11:00 ruang A101
- ✅ zen hapus reminder kas terakhir
- ✅ zen hapus uts terakhir
- ✅ zen hapus reminder rem_xxxx
- ✅ zen reminder tugas EM hari ini jam 5
- ✅ zen ada pembahasan vektor ga?
- ✅ zen cari materi EM tanggal 2025-08-22
- ✅ zen simpan materi EM hari ini caption pengantar EM
- ✅ zen cari materi EM keyword pengantar
- ✅ zen cari materi EM rentang 2025-08-01 sampai 2025-08-31
- ❌ zen kontak dosen kalkulus siapa? — calls= text=Saya menemukan kontak dosen untuk Kalkulus:
- Nama: pak Zulkifli
- Email: zulkifli@example.com
- Nomor Telepon: 08123456789
- ✅ zen nomor Dr Siti ada?
- ✅ zen email dosen kalkulus
- ✅ zen dosen EM siapa?
- ✅ zen kontak dosen basis data
- ✅ zen set barang bawaan EM kalkulator dan penggaris
- ✅ zen hapus barang penggaris untuk EM
- ✅ zen hapus semua barang EM
- ✅ zen set barang bawaan Medan Elektromagnetik spidol papan hapus penggaris
- ✅ zen set barang bawaan Kalkulus penghapus penggaris T
- ✅ @ll besok kumpul jam 7 ya
- ✅ zen set hidrasi 2500 ml sehari gelas 250
- ✅ zen hidrasi target apa?
