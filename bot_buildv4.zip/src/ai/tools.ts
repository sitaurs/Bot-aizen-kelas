import { z } from 'zod';
import { getData, saveData, updateData } from '../storage/files.js';
import { buildEnrichedSchedule, findLecturerByCourse, DayMap, EnrichedClass } from '../storage/loaders.js';
import { generateReminderId, generateExamId, generateCashId, generateMaterialId } from '../utils/id.js';
import { getToday, getDayName, normalizeRelativeDate } from '../utils/time.js';
import { logger } from '../utils/logger.js';
import { 
  ClassSchedule, 
  ScheduleOverride, 
  Reminder, 
  Exam, 
  CashReminder, 
  MaterialEntry,
  Lecturer 
} from '../types/index.js';


function logToolStart(name: string, args: any) {
  logger.info({ tool: name, args }, 'tool.start');
}
function logToolSuccess(name: string, result: any) {
  logger.info({ tool: name, result }, 'tool.success');
}

// Function declarations for Gemini AI
export const tools = [
  {
    name: 'getTodayScheduleEnriched',
    description: 'Mengambil jadwal enriched untuk hari ini (dengan dosen & WA)',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'getScheduleByDay',
    description: 'Mengambil jadwal enriched untuk hari tertentu',
    parameters: {
      type: 'object',
      properties: {
        dayName: { type: 'string', enum: ['senin','selasa','rabu','kamis','jumat'] }
      },
      required: ['dayName']
    }
  },
  {
    name: 'getWeeklySchedule',
    description: 'Mengambil jadwal enriched untuk satu minggu (Senin–Jumat)',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'lookupLecturerByCourse',
    description: 'Mencari dosen berdasarkan nama mata kuliah',
    parameters: {
      type: 'object',
      properties: { course: { type: 'string' } },
      required: ['course']
    }
  },
  {
    name: 'getTodayInfo',
    description: 'Mengembalikan tanggal hari ini (Asia/Jakarta) dan nama harinya',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'askClarify',
    description: 'Meminta pertanyaan klarifikasi ke pengguna saat parameter kurang/ambiguous',
    parameters: {
      type: 'object',
      properties: {
        question: { type: 'string', description: 'Pertanyaan klarifikasi singkat' },
        expect: {
          type: 'array',
          description: 'Daftar slot/parameter yang diharapkan',
          items: { type: 'string' }
        }
      },
      required: ['question']
    }
  },
  {
    name: 'addMaterials',
    description: 'Menambahkan materi (caption + file) ke index dan storage lokal',
    parameters: {
      type: 'object',
      properties: {
        course: { type: 'string', description: 'Nama mata kuliah' },
        dateISO: { type: 'string', description: 'Tanggal materi (YYYY-MM-DD)' },
        caption: { type: 'string', description: 'Caption penjelasan materi' },
        files: {
          type: 'array',
          description: 'Daftar file materi',
          items: {
            type: 'object',
            properties: {
              tempPath: { type: 'string', description: 'Path sementara atau lokal file' },
              filename: { type: 'string', description: 'Nama file' },
              mime: { type: 'string', description: 'MIME type file' }
            },
            required: ['filename', 'mime']
          }
        }
      },
      required: ['course', 'dateISO', 'caption']
    }
  },
  {
    name: 'mentionAll',
    description: 'Mention semua anggota grup dengan pesan',
    parameters: {
      type: 'object',
      properties: {
        groupJid: { type: 'string', description: 'JID grup' },
        text: { type: 'string', description: 'Pesan untuk dikirim' }
      },
      required: ['text']
    }
  },
  {
    name: 'setHydrationPlan',
    description: 'Mengatur target hidrasi harian',
    parameters: {
      type: 'object',
      properties: {
        dailyGoalMl: { type: 'number', description: 'Target ml per hari' },
        glassSizeMl: { type: 'number', description: 'Ukuran gelas ml' }
      },
      required: ['dailyGoalMl', 'glassSizeMl']
    }
  },
  {
    name: 'getHydrationPlan',
    description: 'Mengambil target hidrasi yang tersimpan',
    parameters: { type: 'object', properties: {} }
  },
  {
    name: 'getSchedule',
    description: 'Mendapatkan jadwal kelas untuk hari tertentu',
    parameters: {
      type: 'object',
      properties: {
        date: {
          type: 'string',
          description: 'Tanggal dalam format YYYY-MM-DD (opsional, default hari ini)'
        },
        dayName: {
          type: 'string',
          description: 'Nama hari (Mon, Tue, Wed, Thu, Fri, Sat, Sun)'
        }
      }
    }
  },
  {
    name: 'changeSchedule',
    description: 'Mengubah jadwal sementara untuk mata kuliah tertentu',
    parameters: {
      type: 'object',
      properties: {
        course: {
          type: 'string',
          description: 'Nama mata kuliah'
        },
        dayName: {
          type: 'string',
          description: 'Nama hari relatif (mis. Senin, besok) opsional'
        },
        date: {
          type: 'string',
          description: 'Tanggal dalam format YYYY-MM-DD'
        },
        start: {
          type: 'string',
          description: 'Waktu mulai dalam format HH:mm'
        },
        end: {
          type: 'string',
          description: 'Waktu selesai dalam format HH:mm'
        },
        room: {
          type: 'string',
          description: 'Ruangan (opsional)'
        },
        reason: {
          type: 'string',
          description: 'Alasan perubahan jadwal'
        }
      },
      required: ['course', 'start', 'end']
    }
  },
  {
    name: 'setReminder',
    description: 'Mengatur pengingat tugas atau acara',
    parameters: {
      type: 'object',
      properties: {
        type: {
          type: 'string',
          enum: ['task', 'exam', 'cash', 'item'],
          description: 'Jenis pengingat'
        },
        title: {
          type: 'string',
          description: 'Judul pengingat'
        },
        course: {
          type: 'string',
          description: 'Mata kuliah (opsional)'
        },
        dueISO: {
          type: 'string',
          description: 'Tanggal dan waktu deadline dalam format ISO'
        },
        notes: {
          type: 'string',
          description: 'Catatan tambahan (opsional)'
        }
      },
      required: ['type', 'title', 'dueISO']
    }
  },
  {
    name: 'deleteReminder',
    description: 'Menghapus pengingat berdasarkan ID',
    parameters: {
      type: 'object',
      properties: {
        id: {
          type: 'string',
          description: 'ID pengingat yang akan dihapus'
        }
      },
      required: ['id']
    }
  },
  {
    name: 'setExam',
    description: 'Mengatur jadwal ujian',
    parameters: {
      type: 'object',
      properties: {
        course: {
          type: 'string',
          description: 'Mata kuliah'
        },
        type: {
          type: 'string',
          enum: ['UTS', 'UAS', 'Quiz'],
          description: 'Jenis ujian'
        },
        dateISO: {
          type: 'string',
          description: 'Tanggal ujian dalam format ISO'
        },
        start: {
          type: 'string',
          description: 'Waktu mulai dalam format HH:mm'
        },
        end: {
          type: 'string',
          description: 'Waktu selesai dalam format HH:mm'
        },
        room: {
          type: 'string',
          description: 'Ruangan (opsional)'
        },
        notes: {
          type: 'string',
          description: 'Catatan tambahan (opsional)'
        }
      },
      required: ['course', 'type', 'dateISO', 'start', 'end']
    }
  },
  {
    name: 'deleteExam',
    description: 'Menghapus jadwal ujian berdasarkan ID',
    parameters: {
      type: 'object',
      properties: {
        id: {
          type: 'string',
          description: 'ID ujian yang akan dihapus'
        }
      },
      required: []
    }
  },
  {
    name: 'setCashReminder',
    description: 'Mengatur pengingat pembayaran kas',
    parameters: {
      type: 'object',
      properties: {
        amount: {
          type: 'number',
          description: 'Jumlah yang harus dibayar'
        },
        dueISO: {
          type: 'string',
          description: 'Tanggal deadline dalam format ISO'
        },
        notes: {
          type: 'string',
          description: 'Catatan tambahan (opsional)'
        }
      },
      required: ['amount', 'dueISO']
    }
  },
  {
    name: 'deleteCashReminder',
    description: 'Menghapus pengingat kas berdasarkan ID',
    parameters: {
      type: 'object',
      properties: {
        id: {
          type: 'string',
          description: 'ID pengingat kas yang akan dihapus'
        }
      },
      required: []
    }
  },
  {
    name: 'setCarryItem',
    description: 'Mengatur barang bawaan untuk mata kuliah',
    parameters: {
      type: 'object',
      properties: {
        course: {
          type: 'string',
          description: 'Mata kuliah'
        },
        items: {
          type: 'array',
          items: {
            type: 'string'
          },
          description: 'Daftar barang yang harus dibawa'
        }
      },
      required: ['course', 'items']
    }
  },
  {
    name: 'deleteCarryItem',
    description: 'Menghapus barang bawaan untuk mata kuliah',
    parameters: {
      type: 'object',
      properties: {
        course: {
          type: 'string',
          description: 'Mata kuliah'
        },
        items: {
          type: 'array',
          items: {
            type: 'string'
          },
          description: 'Daftar barang yang akan dihapus (opsional, jika kosong hapus semua)'
        }
      },
      required: ['course']
    }
  },
  {
    name: 'queryMaterials',
    description: 'Mencari materi berdasarkan query',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: 'Kata kunci pencarian'
        },
        course: {
          type: 'string',
          description: 'Mata kuliah (opsional)'
        },
        dateFrom: {
          type: 'string',
          description: 'Tanggal mulai pencarian dalam format YYYY-MM-DD (opsional)'
        },
        dateTo: {
          type: 'string',
          description: 'Tanggal akhir pencarian dalam format YYYY-MM-DD (opsional)'
        },
        topK: {
          type: 'number',
          description: 'Jumlah hasil maksimal (opsional, default 5)'
        }
      },
      required: ['query']
    }
  },
  {
    name: 'getLecturerContact',
    description: 'Mendapatkan kontak dosen berdasarkan nama atau mata kuliah',
    parameters: {
      type: 'object',
      properties: {
        nameOrCourse: {
          type: 'string',
          description: 'Nama dosen atau mata kuliah'
        }
      },
      required: ['nameOrCourse']
    }
  },
  {
    name: 'getLecturerInfo',
    description: 'Mendapatkan info dosen (kode, nama, wa, waJid) berdasarkan code/nama/course',
    parameters: {
      type: 'object',
      properties: {
        code: { type: 'number', description: 'Kode dosen' },
        name: { type: 'string', description: 'Nama dosen' },
        course: { type: 'string', description: 'Nama mata kuliah' }
      }
    }
  },
  {
    name: 'getLecturerSchedule',
    description: 'Mengambil jadwal mengajar dosen berdasarkan code/nama, opsional filter per hari',
    parameters: {
      type: 'object',
      properties: {
        code: { type: 'number', description: 'Kode dosen' },
        name: { type: 'string', description: 'Nama dosen' },
        dayName: { type: 'string', enum: ['senin','selasa','rabu','kamis','jumat'] }
      }
    }
  },
  {
    name: 'getClassLocation',
    description: 'Mendapatkan lokasi kelas untuk mata kuliah tertentu',
    parameters: {
      type: 'object',
      properties: {
        course: {
          type: 'string',
          description: 'Mata kuliah'
        },
        dateISO: {
          type: 'string',
          description: 'Tanggal dalam format ISO (opsional, default hari ini)'
        },
        dayName: {
          type: 'string',
          description: 'Nama hari relatif (mis. hari ini, besok, Senin) opsional'
        }
      },
      required: ['course']
    }
  }
];

// Tool handlers
export async function handleToolCall(functionCall: any): Promise<any> {
  const { name, args } = functionCall;

  try {
    logToolStart(name, args);
    const result = await (async () => {
      switch (name) {
        case 'getTodayScheduleEnriched':
          return await getTodayScheduleEnrichedHandler(args);
        case 'getScheduleByDay':
          return await getScheduleByDayHandler(args);
        case 'getWeeklySchedule':
          return await getWeeklyScheduleHandler(args);
        case 'lookupLecturerByCourse':
          return await lookupLecturerByCourseHandler(args);
        case 'getTodayInfo':
          return await getTodayInfoHandler(args);
        case 'getSchedule':
          return await getScheduleHandler(args);
        case 'changeSchedule':
          return await changeScheduleHandler(args);
        case 'setReminder':
          return await setReminderHandler(args);
        case 'deleteReminder':
          return await deleteReminderHandler(args);
        case 'setExam':
          return await setExamHandler(args);
        case 'deleteExam':
          return await deleteExamHandler(args);
        case 'setCashReminder':
          return await setCashReminderHandler(args);
        case 'deleteCashReminder':
          return await deleteCashReminderHandler(args);
        case 'setCarryItem':
          return await setCarryItemHandler(args);
        case 'deleteCarryItem':
          return await deleteCarryItemHandler(args);
        case 'queryMaterials':
          return await queryMaterialsHandler(args);
        case 'getLecturerContact':
          return await getLecturerContactHandler(args);
        case 'getLecturerInfo':
          return await getLecturerInfoHandler(args);
        case 'getLecturerSchedule':
          return await getLecturerScheduleHandler(args);
        case 'getClassLocation':
          return await getClassLocationHandler(args);
        case 'addMaterials':
          return await addMaterialsHandler(args);
        case 'mentionAll':
          return await mentionAllHandler(args);
        case 'setHydrationPlan':
          return await setHydrationPlanHandler(args);
        case 'getHydrationPlan':
          return await getHydrationPlanHandler(args);
        case 'askClarify':
          return await askClarifyHandler(args);
        default:
          throw new Error(`Unknown function: ${name}`);
      }
    })();
    logToolSuccess(name, result);
    return result;
  } catch (error) {
    logger.error(`Error in tool handler ${name}:`, error as any);
    return { error: (error as any).message };
  }
}

// Handler implementations
async function getScheduleHandler(args: any) {
  const date = args.date || normalizeRelativeDate(args.dayName || '') || getToday();
  const dayName = getDayName(date);
  
  // Use enriched schedule instead of raw schedule
  const enriched = await ensureEnriched();
  const map: any = { mon: 'senin', tue: 'selasa', wed: 'rabu', thu: 'kamis', fri: 'jumat', sat: 'sabtu', sun: 'minggu' };
  const indonesianDay = (dayName ? map[String(dayName).toLowerCase()] : 'senin');
  
  const classes = (enriched as any)[indonesianDay] || [];
  
  // Check for overrides on this specific date
  const schedule = getData('schedule');
  const overrides = schedule.overrides.filter((o: ScheduleOverride) => o.date === date);

  return {
    date,
    dayName: indonesianDay,
    regularSchedule: classes,
    overrides,
    totalClasses: classes.length + overrides.length
  };
}

async function changeScheduleHandler(args: any) {
  if (!args.date) {
    const normalized = normalizeRelativeDate(args.dayName || args.date || '');
    if (normalized) args.date = normalized;
  }
  const override: ScheduleOverride = {
    date: args.date,
    course: args.course,
    start: args.start,
    end: args.end,
    room: args.room,
    reason: args.reason
  };

  await updateData('schedule', (schedule) => {
    schedule.overrides.push(override);
    return schedule;
  });

  return { success: true, message: `Jadwal ${args.course} berhasil diubah untuk ${args.date}` };
}

async function setReminderHandler(args: any) {
  const reminder: Reminder = {
    id: generateReminderId(),
    type: args.type,
    title: args.title,
    course: args.course,
    dueISO: args.dueISO,
    notes: args.notes,
    completed: false
  };

  await updateData('reminders', (reminders) => {
    reminders.push(reminder);
    return reminders;
  });

  return { success: true, id: reminder.id, message: 'Pengingat berhasil ditambahkan' };
}

async function deleteReminderHandler(args: any) {
  await updateData('reminders', (reminders) => {
    return reminders.filter((r: Reminder) => r.id !== args.id);
  });

  return { success: true, message: 'Pengingat berhasil dihapus' };
}

async function setExamHandler(args: any) {
  const exam: Exam = {
    id: generateExamId(),
    course: args.course,
    type: args.type,
    dateISO: args.dateISO,
    start: args.start,
    end: args.end,
    room: args.room,
    notes: args.notes
  };

  await updateData('exams', (exams) => {
    if (!exams) exams = [];
    exams.push(exam);
    return exams;
  });

  return { success: true, id: exam.id, message: 'Jadwal ujian berhasil ditambahkan' };
}

async function deleteExamHandler(args: any) {
  if (args.id) {
    await updateData('exams', (exams) => {
      if (!exams) return [];
      return exams.filter((e: Exam) => e.id !== args.id);
    });
    return { success: true, message: 'Jadwal ujian berhasil dihapus' };
  }
  // delete latest if no id
  let deleted: Exam | null = null as any;
  await updateData('exams', (exams) => {
    if (!exams || exams.length === 0) return exams || [];
    deleted = exams[exams.length - 1];
    return exams.slice(0, -1);
  });
  return deleted ? { success: true, deletedId: deleted.id, message: 'Jadwal ujian terakhir dihapus' } : { success: false, message: 'Tidak ada ujian untuk dihapus' };
}

async function setCashReminderHandler(args: any) {
  const cashReminder: CashReminder = {
    id: generateCashId(),
    amount: args.amount,
    dueISO: args.dueISO,
    notes: args.notes,
    paid: false
  };

  await updateData('cashReminders', (reminders) => {
    if (!reminders) reminders = [];
    reminders.push(cashReminder);
    return reminders;
  });

  return { success: true, id: cashReminder.id, message: 'Pengingat kas berhasil ditambahkan' };
}

async function deleteCashReminderHandler(args: any) {
  if (args.id) {
    await updateData('cashReminders', (reminders) => {
      if (!reminders) return [];
      return reminders.filter((r: CashReminder) => r.id !== args.id);
    });
    return { success: true, message: 'Pengingat kas berhasil dihapus' };
  }
  // delete latest if no id
  let deleted: CashReminder | null = null as any;
  await updateData('cashReminders', (reminders) => {
    if (!reminders || reminders.length === 0) return reminders || [];
    deleted = reminders[reminders.length - 1];
    return reminders.slice(0, -1);
  });
  return deleted ? { success: true, deletedId: deleted.id, message: 'Pengingat kas terakhir dihapus' } : { success: false, message: 'Tidak ada pengingat kas untuk dihapus' };
}

async function setCarryItemHandler(args: any) {
  await updateData('items', (items) => {
    items[args.course] = args.items;
    return items;
  });

  return { success: true, message: `Barang bawaan untuk ${args.course} berhasil diatur` };
}

async function deleteCarryItemHandler(args: any) {
  await updateData('items', (items) => {
    if (args.items && args.items.length > 0) {
      // Remove specific items
      items[args.course] = items[args.course]?.filter((item: string) => !args.items.includes(item)) || [];
    } else {
      // Remove all items for the course
      delete items[args.course];
    }
    return items;
  });

  return { success: true, message: 'Barang bawaan berhasil dihapus' };
}

async function queryMaterialsHandler(args: any) {
  const materials = getData('materials');
  const results = [];

  for (const [date, entries] of Object.entries(materials.byDate)) {
    for (const entry of entries as MaterialEntry[]) {
      if (args.course && entry.course.toLowerCase() !== args.course.toLowerCase()) {
        continue;
      }

      if (args.dateFrom && date < args.dateFrom) continue;
      if (args.dateTo && date > args.dateTo) continue;

      const searchText = `${entry.course} ${entry.captions.join(' ')}`.toLowerCase();
      if (searchText.includes(args.query.toLowerCase())) {
        results.push({
          id: entry.id,
          course: entry.course,
          date: entry.dateISO,
          captions: entry.captions,
          files: entry.files
        });
      }
    }
  }

  const topK = args.topK || 5;
  return { materials: results.slice(0, topK) }; // Wrap array in object
}

async function getLecturerContactHandler(args: any) {
  const enriched = await ensureEnriched();
  const queryRaw = String(args.nameOrCourse || '').trim();
  const query = queryRaw.toLowerCase();
  const pool: any[] = [];
  for (const day of Object.keys(enriched)) {
    for (const cls of (enriched as any)[day]) {
      pool.push({ course: cls.course, lecturer: cls.lecturer });
    }
  }
  // Dedup by lecturer code
  const seenCode = new Set<number>();
  const unique = pool.filter((e) => { const c = e.lecturer.code; if (seenCode.has(c)) return false; seenCode.add(c); return true; });
  // Direct contains first (handles full names/courses)
  const direct = unique.filter(e => e.course.toLowerCase().includes(query) || e.lecturer.name.toLowerCase().includes(query));
  let results = direct.map(e => e.lecturer);
  // Fuzzy fallback for abbreviations/typos (jarkom, traffi, mikrokon, antena)
  if (results.length === 0) {
    const Fuse = (await import('fuse.js')).default as any;
    const fuse = new Fuse(unique, { keys: ['course', 'lecturer.name'], includeScore: true, threshold: 0.45, ignoreLocation: true, distance: 100 });
    const altQueries = [
      queryRaw,
      queryRaw.replace(/jarkom/gi, 'Jaringan Komputer'),
      queryRaw.replace(/traff(i|ik)/gi, 'Rekayasa Trafik'),
      queryRaw.replace(/mikrokon/gi, 'Mikrokontroler'),
      queryRaw.replace(/antena/gi, 'Antena')
    ].filter((s, i, arr) => s && arr.indexOf(s) === i);
    for (const q of altQueries) {
      const hit = fuse.search(q);
      if (hit && hit.length) {
        results = hit.slice(0, 3).map((h: any) => h.item.lecturer);
        break;
      }
    }
  }
  // Dedup final list by code
  const seen = new Set<number>();
  const lecturers = results.filter((l: any) => { if (seen.has(l.code)) return false; seen.add(l.code); return true; });
  return { lecturers };
}

async function getClassLocationHandler(args: any) {
  const schedule = getData('schedule');
  const date = args.dateISO || normalizeRelativeDate(args.dayName || '') || getToday();
  const dn = getDayName(date);
  const map: any = { mon: 'senin', tue: 'selasa', wed: 'rabu', thu: 'kamis', fri: 'jumat', sat: 'sabtu', sun: 'minggu' };
  const idDay = (dn ? map[String(dn).toLowerCase()] : 'senin');

  // Check regular schedule (Indonesian keys)
  const daySchedule = (schedule.days as any)[idDay] || [];
  const courseSchedule = daySchedule.find((s: ClassSchedule) => 
    s.course.toLowerCase() === args.course.toLowerCase()
  );

  // Check overrides
  const override = schedule.overrides.find((o: ScheduleOverride) => 
    o.date === date && o.course.toLowerCase() === args.course.toLowerCase()
  );

  if (override) {
    return {
      course: args.course,
      date,
      room: override.room,
      start: override.start,
      end: override.end,
      isOverride: true,
      reason: override.reason
    };
  }

  if (courseSchedule) {
    return {
      course: args.course,
      date,
      room: courseSchedule.room,
      start: courseSchedule.start,
      end: courseSchedule.end,
      isOverride: false
    };
  }

  return { error: `Tidak ada jadwal untuk ${args.course} pada ${date}` };
}

// === New handlers ===
async function ensureEnriched(): Promise<DayMap> {
  let enriched = getData('enrichedSchedule');
  if (!enriched) {
    enriched = await buildEnrichedSchedule();
  }
  return enriched as DayMap;
}

async function getTodayScheduleEnrichedHandler(_args: any) {
  const enriched = await ensureEnriched();
  const today = getToday();
  const dn = getDayName(today);
  const map: any = { mon: 'senin', tue: 'selasa', wed: 'rabu', thu: 'kamis', fri: 'jumat', sat: 'sabtu', sun: 'minggu' };
  const day = (dn ? map[String(dn).toLowerCase()] : 'senin');
  const classes = (enriched as any)[day] || [];
  return { dayName: day, classes };
}

async function getScheduleByDayHandler(args: any) {
  const enriched = await ensureEnriched();
  const day = String(args.dayName).toLowerCase();
  const classes = (enriched as any)[day] || [];
  return { classes };
}

async function getWeeklyScheduleHandler(_args: any) {
  const enriched = await ensureEnriched();
  const order: string[] = ['senin','selasa','rabu','kamis','jumat'];
  const week = order.map((d) => ({ dayName: d, classes: (enriched as any)[d] || [] }));
  return { week };
}

async function lookupLecturerByCourseHandler(args: any) {
  const enriched = await ensureEnriched();
  const lec = findLecturerByCourse(enriched, args.course || '');
  if (!lec) return { error: 'Tidak ditemukan' };
  return { name: lec.name, wa: lec.wa, code: lec.code };
}

async function getLecturerInfoHandler(args: any) {
  const enriched = await ensureEnriched();
  const byCode = typeof args.code === 'number' ? args.code : undefined;
  const name = args.name ? String(args.name).toLowerCase() : undefined;
  const course = args.course ? String(args.course).toLowerCase() : undefined;
  const results: any[] = [];
  for (const day of Object.keys(enriched)) {
    for (const cls of (enriched as any)[day]) {
      const l = cls.lecturer;
      if ((byCode !== undefined && l.code === byCode) ||
          (name && l.name.toLowerCase().includes(name)) ||
          (course && cls.course.toLowerCase().includes(course))) {
        results.push({ code: l.code, name: l.name, wa: l.wa, waJid: l.waJid });
      }
    }
  }
  // dedup by code
  const seen = new Set<number>();
  const lecturers = results.filter(l => { if (seen.has(l.code)) return false; seen.add(l.code); return true; });
  return { lecturers };
}

async function getLecturerScheduleHandler(args: any) {
  const enriched = await ensureEnriched();
  const byCode = typeof args.code === 'number' ? args.code : undefined;
  const name = args.name ? String(args.name).toLowerCase() : undefined;
  const dayName = args.dayName ? String(args.dayName).toLowerCase() : undefined;
  const days = dayName ? [dayName] : Object.keys(enriched);
  const classes: any[] = [];
  for (const day of days) {
    for (const cls of (enriched as any)[day] || []) {
      const l = cls.lecturer;
      if ((byCode !== undefined && l.code === byCode) || (name && l.name.toLowerCase().includes(name))) {
        classes.push({ dayName: day, course: cls.course, start: cls.start, end: cls.end, room: cls.room, lecturer: l });
      }
    }
  }
  return { classes };
}
async function addMaterialsHandler(args: any) {
  // Minimal: only update materials index; actual file save handled elsewhere
  const materials = getData('materials');
  const entry: any = {
    id: generateMaterialId(),
    course: args.course,
    dateISO: args.dateISO,
    captions: args.caption ? [args.caption] : [],
    files: (args.files || []).map((f: any) => ({ path: f.tempPath || f.filename, filename: f.filename, mime: f.mime })),
    createdAt: new Date().toISOString()
  };
  if (!materials.byDate[args.dateISO]) materials.byDate[args.dateISO] = [];
  materials.byDate[args.dateISO].push(entry);
  await saveData('materials', materials);
  return { success: true, id: entry.id };
}

async function mentionAllHandler(args: any) {
  // Default to GROUP_JID from env if not provided
  const groupJid = args.groupJid || process.env.GROUP_JID || '';
  return { groupJid, text: args.text, mentionAll: true };
}

async function setHydrationPlanHandler(args: any) {
  const hydration = getData('hydration') || {};
  hydration.dailyGoalMl = args.dailyGoalMl;
  hydration.glassSizeMl = args.glassSizeMl;
  await saveData('hydration', hydration);
  return { success: true, hydration };
}

async function getHydrationPlanHandler(_args: any) {
  const hydration = getData('hydration') || {};
  return { hydration };
}

async function getTodayInfoHandler(_args: any) {
  const date = getToday();
  const dayName = getDayName(date);
  return { date, dayName, timezone: 'Asia/Jakarta' };
}

async function askClarifyHandler(args: any) {
  // Echo back the clarification schema so the model can craft a question naturally
  const question = args?.question || 'Boleh jelaskan lebih spesifik?';
  const expect = Array.isArray(args?.expect) ? args.expect : [];
  return { ok: true, question, expect };
}
